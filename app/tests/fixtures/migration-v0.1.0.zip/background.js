//#region node_modules/zod/v4/core/util.js
function e(e) {
	let t = Object.values(e).filter((e) => typeof e == "number");
	return Object.entries(e).filter(([e, n]) => t.indexOf(+e) === -1).map(([e, t]) => t);
}
function t(e, t = "|") {
	return e.map((e) => y(e)).join(t);
}
function n(e, t) {
	return typeof t == "bigint" ? t.toString() : t;
}
function r(e) {
	return { get value() {
		{
			let t = e();
			return Object.defineProperty(this, "value", { value: t }), t;
		}
	} };
}
function i(e) {
	return e == null;
}
function a(e) {
	let t = +!!e.startsWith("^"), n = e.endsWith("$") ? e.length - 1 : e.length;
	return e.slice(t, n);
}
function o(e, t) {
	let n = e / t, r = Math.round(n), i = 4 * 2 ** -52 * Math.max(Math.abs(n), 1);
	return Math.abs(n - r) < i ? 0 : n - r;
}
function s(e, t, n) {
	Object.defineProperty(e, t, {
		value: n,
		writable: !0,
		enumerable: !0,
		configurable: !0
	});
}
function c(...e) {
	let t = {};
	for (let n of e) {
		let e = Object.getOwnPropertyDescriptors(n);
		Object.assign(t, e);
	}
	return Object.defineProperties({}, t);
}
function l(e) {
	return JSON.stringify(e);
}
function u(e) {
	return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var d = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {};
function f(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var p = /* @__PURE__*/ r(() => {
	if (D.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare")) return !1;
	try {
		return Function(""), !0;
	} catch {
		return !1;
	}
});
function m(e) {
	if (f(e) === !1) return !1;
	let t = e.constructor;
	if (t === void 0 || typeof t != "function") return !0;
	let n = t.prototype;
	return f(n) !== !1 && Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") !== !1;
}
function h(e) {
	return m(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
var ee = /* @__PURE__*/ new Set([
	"string",
	"number",
	"symbol"
]);
function g(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function _(e, t, n) {
	let r = new e._zod.constr(t ?? e._zod.def);
	return (!t || n?.parent) && (r._zod.parent = e), r;
}
function v(e) {
	let t = e;
	if (!t) return {};
	if (typeof t == "string") return { error: () => t };
	if (t?.message !== void 0) {
		if (t?.error !== void 0) throw Error("Cannot specify both `message` and `error` params");
		t.error = t.message;
	}
	return delete t.message, typeof t.error == "string" ? {
		...t,
		error: () => t.error
	} : t;
}
function y(e) {
	return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function te(e) {
	return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
var ne = {
	safeint: [-(2 ** 53 - 1), 2 ** 53 - 1],
	int32: [-2147483648, 2147483647],
	uint32: [0, 4294967295],
	float32: [-34028234663852886e22, 34028234663852886e22],
	float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};
function re(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".pick() cannot be used on object schemas containing refinements");
	return _(e, c(e._zod.def, {
		get shape() {
			let e = {};
			for (let r of Reflect.ownKeys(t)) {
				if (!Object.prototype.hasOwnProperty.call(n.shape, r)) throw Error(`Unrecognized key: "${String(r)}"`);
				t[r] && s(e, r, n.shape[r]);
			}
			return s(this, "shape", e), e;
		},
		checks: []
	}));
}
function ie(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".omit() cannot be used on object schemas containing refinements");
	return _(e, c(e._zod.def, {
		get shape() {
			let r = { ...e._zod.def.shape };
			for (let e of Reflect.ownKeys(t)) {
				if (!Object.prototype.hasOwnProperty.call(n.shape, e)) throw Error(`Unrecognized key: "${String(e)}"`);
				t[e] && delete r[e];
			}
			return s(this, "shape", r), r;
		},
		checks: []
	}));
}
function ae(e, t) {
	if (!m(t)) throw Error("Invalid input to extend: expected a plain object");
	let n = e._zod.def.checks;
	if (n && n.length > 0) {
		let n = e._zod.def.shape;
		for (let e of Reflect.ownKeys(t)) if (Object.getOwnPropertyDescriptor(n, e) !== void 0) throw Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
	}
	return _(e, c(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return s(this, "shape", n), n;
	} }));
}
function oe(e, t) {
	if (!m(t)) throw Error("Invalid input to safeExtend: expected a plain object");
	return _(e, c(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return s(this, "shape", n), n;
	} }));
}
function se(e, t) {
	if (!t?._zod?.def) throw Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
	if (e._zod.def.checks?.length) throw Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
	return _(e, c(e._zod.def, {
		get shape() {
			let n = {
				...e._zod.def.shape,
				...t._zod.def.shape
			};
			return s(this, "shape", n), n;
		},
		get catchall() {
			return t._zod.def.catchall;
		},
		checks: t._zod.def.checks ?? []
	}));
}
function ce(e, t, n, r = "partial") {
	let i = t._zod.def.checks;
	if (i && i.length > 0) throw Error(`.${r}() cannot be used on object schemas containing refinements`);
	return _(t, c(t._zod.def, {
		get shape() {
			let r = t._zod.def.shape, i = { ...r };
			if (n) for (let t of Reflect.ownKeys(n)) {
				if (!Object.prototype.hasOwnProperty.call(r, t)) throw Error(`Unrecognized key: "${String(t)}"`);
				n[t] && (i[t] = e ? new e({
					type: "optional",
					innerType: r[t]
				}) : r[t]);
			}
			else for (let t of Reflect.ownKeys(r)) i[t] = e ? new e({
				type: "optional",
				innerType: r[t]
			}) : r[t];
			return s(this, "shape", i), i;
		},
		checks: []
	}));
}
function le(e, t, n) {
	return _(t, c(t._zod.def, { get shape() {
		let r = t._zod.def.shape, i = { ...r };
		if (n) for (let t of Reflect.ownKeys(n)) {
			if (!Object.prototype.hasOwnProperty.call(i, t)) throw Error(`Unrecognized key: "${String(t)}"`);
			n[t] && (i[t] = new e({
				type: "nonoptional",
				innerType: r[t]
			}));
		}
		else for (let t of Reflect.ownKeys(r)) i[t] = new e({
			type: "nonoptional",
			innerType: r[t]
		});
		return s(this, "shape", i), i;
	} }));
}
function b(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue !== !0) return !0;
	return !1;
}
function ue(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue === !1) return !0;
	return !1;
}
function de(e, t) {
	return t.map((t) => {
		var n;
		return (n = t).path ?? (n.path = []), t.path.unshift(e), t;
	});
}
function fe(e) {
	return typeof e == "string" ? e : e?.message;
}
function pe(e, t, n) {
	var r;
	for (let i = t; i < e.length; i++) (r = e[i]).schema ?? (r.schema = n);
}
function x(e, t, n) {
	var r;
	let i = e.inst?._zod?.traits;
	i?.has("$ZodType") && (i.has("$ZodCheck") ? (r = e).schema ?? (r.schema = e.inst) : e.schema = e.inst);
	let a = e.schema === e.inst ? void 0 : e.schema?._zod.def?.error, o = e.message ? e.message : fe(e.inst?._zod.def?.error?.(e)) ?? fe(a?.(e)) ?? fe(t?.error?.(e)) ?? fe(n.customError?.(e)) ?? fe(n.localeError?.(e)) ?? "Invalid input", { inst: s, schema: c, continue: l, input: u, ...d } = e;
	return d.path ??= [], d.message = o, t?.reportInput && (d.input = u), d;
}
var me = /[\uD800-\uDBFF]/;
function he(e) {
	let t = e.length;
	if (!me.test(e)) return t;
	let n = t;
	for (let r = 0; r < t - 1; r++) (e.charCodeAt(r) & 64512) == 55296 && (e.charCodeAt(r + 1) & 64512) == 56320 && (n--, r++);
	return n;
}
function ge(e) {
	return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function _e(e) {
	let t = typeof e;
	switch (t) {
		case "number": return Number.isNaN(e) ? "nan" : "number";
		case "object": {
			if (e === null) return "null";
			if (Array.isArray(e)) return "array";
			let t = e;
			if (t && Object.getPrototypeOf(t) !== Object.prototype && "constructor" in t && t.constructor) return t.constructor.name;
		}
	}
	return t;
}
function ve(...e) {
	let [t, n, r] = e;
	return typeof t == "string" ? {
		message: t,
		code: "custom",
		input: n,
		inst: r
	} : { ...t };
}
function ye(e, t) {
	for (let n in t) {
		let r = Object.getOwnPropertyDescriptor(t, n);
		r.get ? Object.defineProperty(e, n, {
			...r,
			enumerable: !1
		}) : xe(e, n, r.value);
	}
}
function S(e, t, n, r = !0) {
	return Object.defineProperty(e, t, {
		configurable: !0,
		writable: !0,
		enumerable: r,
		value: n
	}), n;
}
function be(e, t, n) {
	return S(e, t, n, !1);
}
function xe(e, t, n) {
	Object.defineProperty(e, t, {
		configurable: !0,
		get() {
			return this == null ? n : S(this, t, n.bind(this));
		},
		set(e) {
			S(this, t, e);
		}
	});
}
function Se(e, t) {
	let n = Object.getPrototypeOf(e);
	return t in n ? void 0 : n;
}
var Ce, C = !1, we = {
	configurable: !0,
	get() {
		C = !0;
	}
};
function w(e, t, n) {
	let r = Object.getPrototypeOf(e._zod);
	if (t in r && Ce !== e._zod) {
		Ce = void 0;
		return;
	}
	Ce = e._zod, Object.defineProperty(r, t, {
		configurable: !0,
		get() {
			Object.defineProperty(this, t, we);
			let e = C;
			C = !1;
			try {
				let r = n(this);
				return C ? delete this[t] : Object.defineProperty(this, t, {
					configurable: !0,
					writable: !0,
					value: r
				}), C ||= e, r;
			} catch (n) {
				throw delete this[t], C ||= e, n;
			}
		},
		set(e) {
			Object.defineProperty(this, t, {
				configurable: !0,
				writable: !0,
				value: e
			});
		}
	});
}
function Te(e, t, n, r) {
	let i = Se(e, t);
	i && Object.defineProperty(i, t, {
		configurable: !0,
		get() {
			let e = {
				configurable: !0,
				writable: !0,
				enumerable: r,
				value: void 0
			};
			return Object.defineProperty(this, t, e), e.value = n(this), Object.defineProperty(this, t, e), e.value;
		},
		set(e) {
			Object.defineProperty(this, t, {
				configurable: !0,
				writable: !0,
				enumerable: r,
				value: e
			});
		}
	});
}
var Ee = "~constantCatch";
function De(e) {
	let t = () => e;
	return t[Ee] = !0, t;
}
//#endregion
//#region node_modules/zod/v4/core/core.js
var Oe, ke = {
	value: void 0,
	enumerable: !1
}, Ae = "captureStackTrace" in Error ? Error : null;
function je(e) {
	let t = Ae;
	if (t) {
		let n = t.stackTraceLimit;
		if (typeof n == "number") {
			try {
				t.stackTraceLimit = 0;
			} catch {
				return Ae = null, new e();
			}
			try {
				return new e();
			} finally {
				t.stackTraceLimit = n;
			}
		}
	}
	return new e();
}
function T(e, t, n, r) {
	let i = {};
	function a(e) {
		this.def = e, this.constr = d, this.traits = /* @__PURE__ */ new Set();
	}
	a.prototype = i;
	let o = n, s = o && /* @__PURE__ */ new WeakSet();
	function c(n, r) {
		if (!n._zod) {
			ke.value = new a(r);
			try {
				Object.defineProperty(n, "_zod", ke);
			} finally {
				ke.value = void 0;
			}
		}
		if (n._zod.traits.has(e)) return;
		if (n._zod.traits.add(e), t(n, r), s) {
			let e = Object.getPrototypeOf(n), t = n._zod.constr.prototype, r = e;
			for (; r && r !== t;) r = Object.getPrototypeOf(r);
			let i = r ?? e;
			s.has(i) || (s.add(i), ye(i, o));
		}
		let i = d.prototype;
		for (let e in i) Object.prototype.hasOwnProperty.call(i, e) && (e in n || (n[e] = i[e].bind(n)));
	}
	let l = r?.Parent ?? Object;
	class u extends l {}
	Object.defineProperty(u, "name", { value: e });
	function d(e) {
		let t = r?.Parent ? je(u) : this;
		c(t, e);
		let n = t._zod.deferred;
		if (n) {
			for (let e of n) e();
			t._zod.deferred = void 0;
		}
		let i = globalThis.__zod_globalConfig?.postProcessor;
		return i && i(t), t;
	}
	return Object.defineProperty(d, "init", { value: c }), Object.defineProperty(d, Symbol.hasInstance, { value: (t) => r?.Parent && t instanceof r.Parent ? !0 : t?._zod?.traits?.has(e) }), Object.defineProperty(d, "name", { value: e }), d;
}
var E = class extends Error {
	constructor() {
		super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
	}
}, Me = class extends Error {
	constructor(e) {
		super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError";
	}
};
(Oe = globalThis).__zod_globalConfig ?? (Oe.__zod_globalConfig = {});
var D = globalThis.__zod_globalConfig;
function O(e) {
	return e && Object.assign(D, e), D;
}
//#endregion
//#region node_modules/zod/v4/core/errors.js
function Ne() {
	let e = this._zod;
	return e.message ??= JSON.stringify(e.def, n, 2), e.message;
}
function Pe(e) {
	this._zod.message = e;
}
var Fe = {
	get: Ne,
	set: Pe,
	enumerable: !0,
	configurable: !0
}, Ie = {
	value: void 0,
	enumerable: !1
}, Le = {
	value: void 0,
	enumerable: !1
}, Re = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), ze = (e, t) => {
	e.name = "$ZodError", Ie.value = e._zod, Object.defineProperty(e, "_zod", Ie), Le.value = t, Object.defineProperty(e, "issues", Le), Ie.value = void 0, Le.value = void 0, Object.defineProperty(e, "message", Fe);
	let n = Object.getPrototypeOf(e);
	Re.has(n) || (Re.add(n), Object.defineProperty(n, "toString", {
		configurable: !0,
		enumerable: !1,
		get() {
			let e = () => this.message;
			return Object.defineProperty(this, "toString", {
				value: e,
				configurable: !0,
				writable: !0
			}), e;
		},
		set(e) {
			Object.defineProperty(this, "toString", {
				value: e,
				configurable: !0,
				writable: !0
			});
		}
	}));
}, Be = T("$ZodError", ze), Ve = T("$ZodError", ze, void 0, { Parent: Error });
function He(e, t, n) {
	return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, {
		value: n(),
		writable: !0,
		enumerable: !0,
		configurable: !0
	}) : e[t] = n()), e[t];
}
function Ue(e, t = (e) => e.message) {
	let n = {}, r = [];
	for (let i of e.issues) i.path.length > 0 ? He(n, i.path[0], () => []).push(t(i)) : r.push(t(i));
	return {
		formErrors: r,
		fieldErrors: n
	};
}
function We(e, t = (e) => e.message) {
	let n = { _errors: [] }, r = (e, i = []) => {
		for (let a of e.issues) if (a.code === "invalid_union" && a.errors.length) a.errors.map((e) => r({ issues: e }, [...i, ...a.path]));
		else if (a.code === "invalid_key") r({ issues: a.issues }, [...i, ...a.path]);
		else if (a.code === "invalid_element") r({ issues: a.issues }, [...i, ...a.path]);
		else {
			let e = [...i, ...a.path];
			if (e.length === 0) n._errors.push(t(a));
			else {
				let r = n, i = 0;
				for (; i < e.length;) {
					let n = e[i], o = i === e.length - 1;
					if (n === "_errors") {
						o && r._errors.push(t(a)), i++;
						continue;
					}
					Object.prototype.hasOwnProperty.call(r, n) || Object.defineProperty(r, n, {
						value: { _errors: [] },
						enumerable: !0,
						writable: !0,
						configurable: !0
					});
					let s = r[n];
					o && s._errors.push(t(a)), r = s, i++;
				}
			}
		}
	};
	return r(e), n;
}
//#endregion
//#region node_modules/zod/v4/core/parse.js
function Ge(e, t) {
	return {
		callee: t?.callee ?? e,
		Err: t?.Err
	};
}
var Ke = (e) => {
	let t = (n, r, i, a) => {
		let o = i ? {
			...i,
			async: !1
		} : { async: !1 }, s = n._zod.run({
			value: r,
			issues: []
		}, o);
		if (s instanceof Promise) throw new E();
		if (s.issues.length) {
			let n = new ((a?.Err) ?? e)(s.issues.map((e) => x(e, o, O())));
			throw d(n, a?.callee ?? t), n;
		}
		return s.value;
	};
	return t;
}, qe = (e) => {
	let t = async (n, r, i, a) => {
		let o = i ? {
			...i,
			async: !0
		} : { async: !0 }, s = n._zod.run({
			value: r,
			issues: []
		}, o);
		if (s instanceof Promise && (s = await s), s.issues.length) {
			let n = new ((a?.Err) ?? e)(s.issues.map((e) => x(e, o, O())));
			throw d(n, a?.callee ?? t), n;
		}
		return s.value;
	};
	return t;
}, Je = (e) => (t, n, r) => {
	let i = r ? {
		...r,
		async: !1
	} : { async: !1 }, a = t._zod.run({
		value: n,
		issues: []
	}, i);
	if (a instanceof Promise) throw new E();
	return a.issues.length ? {
		success: !1,
		error: new (e ?? Be)(a.issues.map((e) => x(e, i, O())))
	} : {
		success: !0,
		data: a.value
	};
}, Ye = /* @__PURE__*/ Je(Ve), Xe = (e) => async (t, n, r) => {
	let i = r ? {
		...r,
		async: !0
	} : { async: !0 }, a = t._zod.run({
		value: n,
		issues: []
	}, i);
	return a instanceof Promise && (a = await a), a.issues.length ? {
		success: !1,
		error: new e(a.issues.map((e) => x(e, i, O())))
	} : {
		success: !0,
		data: a.value
	};
}, Ze = /* @__PURE__*/ Xe(Ve), Qe = (e) => {
	let t = Ke(e), n = (e, r, i, a) => {
		let o = i ? {
			...i,
			direction: "backward"
		} : { direction: "backward" };
		return t(e, r, o, Ge(n, a));
	};
	return n;
}, $e = (e) => {
	let t = Ke(e), n = (e, r, i, a) => t(e, r, i, Ge(n, a));
	return n;
}, et = (e) => {
	let t = qe(e), n = async (e, r, i, a) => {
		let o = i ? {
			...i,
			direction: "backward"
		} : { direction: "backward" };
		return await t(e, r, o, Ge(n, a));
	};
	return n;
}, tt = (e) => {
	let t = qe(e), n = async (e, r, i, a) => await t(e, r, i, Ge(n, a));
	return n;
}, nt = (e) => (t, n, r) => {
	let i = r ? {
		...r,
		direction: "backward"
	} : { direction: "backward" };
	return Je(e)(t, n, i);
}, rt = (e) => (t, n, r) => Je(e)(t, n, r), it = (e) => async (t, n, r) => {
	let i = r ? {
		...r,
		direction: "backward"
	} : { direction: "backward" };
	return Xe(e)(t, n, i);
}, at = (e) => async (t, n, r) => Xe(e)(t, n, r), ot = /^[cC][0-9a-z]{6,}$/, st = /^[0-9a-z]+$/, ct = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, lt = /^[0-9a-vA-V]{20}$/, ut = /^[A-Za-z0-9]{27}$/, dt = /^[a-zA-Z0-9_-]{21}$/;
function ft(e) {
	return RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
var pt = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, mt = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, ht = (e) => e ? RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, gt = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, _t = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function vt() {
	return new RegExp(_t, "u");
}
var yt = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, bt = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, xt = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, St = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Ct = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, wt = /^[A-Za-z0-9_-]*$/, Tt = /^https?$/, Et = /^\+[1-9]\d{6,14}$/, Dt = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Ot(e) {
	return RegExp(`^${e}$`);
}
var kt = /*@__PURE__*/ Ot(Dt);
function At(e) {
	let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
	return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function jt(e) {
	return RegExp(`^${At(e)}$`);
}
function Mt(e) {
	let t = ["Z"];
	e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
	let n = `${At({
		precision: e.precision,
		seconds: !0
	})}(?:${t.join("|")})`, r = e.local ? `${n}|${At({ precision: e.precision })}` : n;
	return RegExp(`^${Dt}T(?:${r})$`);
}
var Nt = (e) => {
	let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
	return RegExp(`^${t}$`);
}, Pt = /^-?\d+$/, Ft = /^-?\d+(?:\.\d+)?$/, It = /^(?:true|false)$/i, Lt = /^[^A-Z]*$/, Rt = /^[^a-z]*$/, k = /*@__PURE__*/ T("$ZodCheck", (e, t) => {
	var n;
	e._zod ??= {}, e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), zt = (e) => {
	let t = e.value;
	return !i(t) && t.length !== void 0;
}, Bt = {
	number: "number",
	bigint: "bigint",
	object: "date"
}, Vt = /*@__PURE__*/ T("$ZodCheckLessThan", (e, t) => {
	k.init(e, t);
	let n = Bt[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.maximum : n.exclusiveMaximum) ?? Infinity;
		t.value < r && (t.inclusive ? n.maximum = t.value : n.exclusiveMaximum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value <= t.value : r.value < t.value) || r.issues.push({
			origin: Bt[typeof r.value] ?? n,
			code: "too_big",
			maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), Ht = /*@__PURE__*/ T("$ZodCheckGreaterThan", (e, t) => {
	k.init(e, t);
	let n = Bt[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.minimum : n.exclusiveMinimum) ?? -Infinity;
		t.value > r && (t.inclusive ? n.minimum = t.value : n.exclusiveMinimum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value >= t.value : r.value > t.value) || r.issues.push({
			origin: Bt[typeof r.value] ?? n,
			code: "too_small",
			minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), Ut = /*@__PURE__*/ T("$ZodCheckMultipleOf", (e, t) => {
	k.init(e, t), e._zod.onattach.push((e) => {
		var n;
		(n = e._zod.bag).multipleOf ?? (n.multipleOf = t.value);
	}), e._zod.check = (n) => {
		if (typeof n.value != typeof t.value) throw Error("Cannot mix number and bigint in multiple_of check.");
		(typeof n.value == "bigint" ? t.value !== BigInt(0) && n.value % t.value === BigInt(0) : o(n.value, t.value) === 0) || n.issues.push({
			origin: typeof n.value,
			code: "not_multiple_of",
			divisor: t.value,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Wt = /*@__PURE__*/ T("$ZodCheckNumberFormat", (e, t) => {
	k.init(e, t), t.format = t.format || "float64";
	let n = t.format?.includes("int"), r = n ? "int" : "number", [i, a] = ne[t.format];
	e._zod.onattach.push((e) => {
		let r = e._zod.bag;
		r.format = t.format, r.minimum = i, r.maximum = a, n && (r.pattern = Pt);
	}), e._zod.check = (o) => {
		let s = o.value;
		if (n) {
			if (!Number.isInteger(s)) {
				o.issues.push({
					expected: r,
					format: t.format,
					code: "invalid_type",
					continue: !1,
					input: s,
					inst: e
				});
				return;
			}
			if (!Number.isSafeInteger(s)) {
				s > 0 ? o.issues.push({
					input: s,
					code: "too_big",
					maximum: 2 ** 53 - 1,
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				}) : o.issues.push({
					input: s,
					code: "too_small",
					minimum: -(2 ** 53 - 1),
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				});
				return;
			}
		}
		s < i && o.issues.push({
			origin: "number",
			input: s,
			code: "too_small",
			minimum: i,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		}), s > a && o.issues.push({
			origin: "number",
			input: s,
			code: "too_big",
			maximum: a,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		});
	};
}), Gt = /*@__PURE__*/ T("$ZodCheckMaxLength", (e, t) => {
	var n;
	k.init(e, t), (n = e._zod.def).when ?? (n.when = zt), e._zod.onattach.push((e) => {
		let n = e._zod.bag.maximum ?? Infinity;
		t.maximum < n && (e._zod.bag.maximum = t.maximum);
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if ((typeof r == "string" && i > t.maximum ? he(r) : i) <= t.maximum) return;
		let a = ge(r);
		n.issues.push({
			origin: a,
			code: "too_big",
			maximum: t.maximum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), Kt = /*@__PURE__*/ T("$ZodCheckMinLength", (e, t) => {
	var n;
	k.init(e, t), (n = e._zod.def).when ?? (n.when = zt), e._zod.onattach.push((e) => {
		let n = e._zod.bag.minimum ?? -Infinity;
		t.minimum > n && (e._zod.bag.minimum = t.minimum);
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if ((typeof r == "string" && i >= t.minimum && i < t.minimum * 2 ? he(r) : i) >= t.minimum) return;
		let a = ge(r);
		n.issues.push({
			origin: a,
			code: "too_small",
			minimum: t.minimum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), qt = /*@__PURE__*/ T("$ZodCheckLengthEquals", (e, t) => {
	var n;
	k.init(e, t), (n = e._zod.def).when ?? (n.when = zt), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.minimum = t.length, n.maximum = t.length, n.length = t.length;
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length, a = typeof r == "string" && i >= t.length && i <= t.length * 2 ? he(r) : i;
		if (a === t.length) return;
		let o = ge(r), s = a > t.length;
		n.issues.push({
			origin: o,
			...s ? {
				code: "too_big",
				maximum: t.length
			} : {
				code: "too_small",
				minimum: t.length
			},
			inclusive: !0,
			exact: !0,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Jt = /*@__PURE__*/ T("$ZodCheckStringFormat", (e, t) => {
	var n, r;
	k.init(e, t), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.format = t.format, t.pattern && (n.patterns ??= /* @__PURE__ */ new Set(), n.patterns.add(t.pattern));
	}), t.pattern ? (n = e._zod).check ?? (n.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: t.format,
			input: n.value,
			...t.pattern ? { pattern: t.pattern.toString() } : {},
			inst: e,
			continue: !t.abort
		});
	}) : (r = e._zod).check ?? (r.check = () => {});
}), Yt = /*@__PURE__*/ T("$ZodCheckRegex", (e, t) => {
	Jt.init(e, t), e._zod.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "regex",
			input: n.value,
			pattern: t.pattern.toString(),
			inst: e,
			continue: !t.abort
		});
	};
}), Xt = /*@__PURE__*/ T("$ZodCheckLowerCase", (e, t) => {
	t.pattern ??= Lt, Jt.init(e, t);
}), Zt = /*@__PURE__*/ T("$ZodCheckUpperCase", (e, t) => {
	t.pattern ??= Rt, Jt.init(e, t);
}), Qt = /*@__PURE__*/ T("$ZodCheckIncludes", (e, t) => {
	k.init(e, t);
	let n = g(t.includes), r = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
	t.pattern = r, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(r);
	}), e._zod.check = (n) => {
		n.value.includes(t.includes, t.position) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "includes",
			includes: t.includes,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), $t = /*@__PURE__*/ T("$ZodCheckStartsWith", (e, t) => {
	k.init(e, t);
	let n = RegExp(`^${g(t.prefix)}.*`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.startsWith(t.prefix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "starts_with",
			prefix: t.prefix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), en = /*@__PURE__*/ T("$ZodCheckEndsWith", (e, t) => {
	k.init(e, t);
	let n = RegExp(`.*${g(t.suffix)}$`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.endsWith(t.suffix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "ends_with",
			suffix: t.suffix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), tn = /*@__PURE__*/ T("$ZodCheckOverwrite", (e, t) => {
	k.init(e, t), e._zod.check = (e) => {
		e.value = t.tx(e.value);
	};
}), nn = class {
	constructor(e = [], t = {}) {
		this.content = [], this.indent = 0, this.args = e, this.closed = t;
	}
	indented(e) {
		this.indent += 1, e(this), --this.indent;
	}
	write(e) {
		if (typeof e == "function") {
			e(this, { execution: "sync" }), e(this, { execution: "async" });
			return;
		}
		let t = e.split("\n").filter((e) => e), n = Math.min(...t.map((e) => e.length - e.trimStart().length)), r = t.map((e) => e.slice(n)).map((e) => " ".repeat(this.indent * 2) + e);
		for (let e of r) this.content.push(e);
	}
	compile() {
		let e = Function, t = this?.content ?? [""];
		return new e(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {\n${t.join("\n")}\n};`)(...Object.values(this.closed));
	}
}, rn = {
	major: 4,
	minor: 5,
	patch: 4
}, A = /*@__PURE__*/ T("$ZodType", (e, t) => {
	var n;
	e ??= {}, e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = rn;
	let r = e._zod.def.checks, i = e._zod.traits.has("$ZodCheck") ? [e, ...r ?? []] : r?.length ? [...r] : [];
	for (let t of i) for (let n of t._zod.onattach) n(e);
	if (i.length === 0) (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
		e._zod.run = e._zod.parse;
	});
	else {
		let t = (t, n, r) => {
			if (t.memo) return t;
			let i = b(t), a;
			for (let o of n) {
				if (o._zod.def.when) {
					if (ue(t) || !o._zod.def.when(t)) continue;
				} else if (i) continue;
				let n = t.issues.length, s = o._zod.check(t);
				if (s instanceof Promise && r?.async === !1) throw new E();
				if (a || s instanceof Promise) a = (a ?? Promise.resolve()).then(async () => {
					await s, t.issues.length !== n && (pe(t.issues, n, e), i ||= b(t, n));
				});
				else {
					if (t.issues.length === n) continue;
					pe(t.issues, n, e), i ||= b(t, n);
				}
			}
			return a ? a.then(() => t) : t;
		}, n = (n, r, a) => {
			if (b(n)) return n.aborted = !0, n;
			let o = t(r, i, a);
			if (o instanceof Promise) {
				if (a.async === !1) throw new E();
				return o.then((t) => e._zod.parse(t, a));
			}
			return e._zod.parse(o, a);
		};
		e._zod.run = (r, a) => {
			if (a.skipChecks) return e._zod.parse(r, a);
			if (a.direction === "backward") {
				let t = e._zod.parse({
					value: r.value,
					issues: []
				}, {
					...a,
					skipChecks: !0
				});
				return t instanceof Promise ? t.then((e) => n(e, r, a)) : n(t, r, a);
			}
			let o = e._zod.parse(r, a);
			if (o instanceof Promise) {
				if (a.async === !1) throw new E();
				return o.then((e) => t(e, i, a));
			}
			return t(o, i, a);
		};
	}
}, {
	get "~standard"() {
		return be(this, "~standard", on(this));
	},
	set "~standard"(e) {
		S(this, "~standard", e);
	}
}), an = (e) => e.success ? { value: e.data } : { issues: e.error?.issues };
function on(e) {
	return {
		validate: (t) => {
			try {
				return an(Ye(e, t));
			} catch {
				return Ze(e, t).then(an);
			}
		},
		vendor: "zod",
		version: 1
	};
}
var sn = /*@__PURE__*/ T("$ZodString", (e, t) => {
	A.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Nt(e._zod.bag), e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = String(n.value);
		} catch {}
		return typeof n.value == "string" || n.issues.push({
			expected: "string",
			code: "invalid_type",
			input: n.value,
			inst: e
		}), n;
	};
}), j = /*@__PURE__*/ T("$ZodStringFormat", (e, t) => {
	Jt.init(e, t), sn.init(e, t);
}), cn = /*@__PURE__*/ T("$ZodGUID", (e, t) => {
	t.pattern ??= mt, j.init(e, t);
}), ln = /*@__PURE__*/ T("$ZodUUID", (e, t) => {
	if (t.version) {
		let e = {
			v1: 1,
			v2: 2,
			v3: 3,
			v4: 4,
			v5: 5,
			v6: 6,
			v7: 7,
			v8: 8
		}[t.version];
		if (e === void 0) throw Error(`Invalid UUID version: "${t.version}"`);
		t.pattern ??= ht(e);
	} else t.pattern ??= ht();
	j.init(e, t);
}), un = /*@__PURE__*/ T("$ZodEmail", (e, t) => {
	t.pattern ??= gt, j.init(e, t);
});
function dn(e, t) {
	if (!t.normalize && t.protocol?.source === Tt.source && !/^https?:\/\//i.test(e)) return 1;
	try {
		return new URL(e);
	} catch {
		return 2;
	}
}
var fn = /[\t\n\r]/g;
function pn(e) {
	return e.replace(fn, "");
}
function mn(e, t) {
	return t.lastIndex = 0, t.test(e.hostname);
}
function hn(e, t) {
	return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
var gn = /*@__PURE__*/ T("$ZodURL", (e, t) => {
	j.init(e, t), e._zod.check = (n) => {
		try {
			let r = n.value.trim(), i = dn(r, t);
			if (i === 1) {
				n.issues.push({
					code: "invalid_format",
					format: "url",
					note: "Invalid URL format",
					input: n.value,
					inst: e,
					continue: !t.abort
				});
				return;
			}
			if (i === 2) {
				n.issues.push({
					code: "invalid_format",
					format: "url",
					input: n.value,
					inst: e,
					continue: !t.abort
				});
				return;
			}
			t.hostname && !mn(i, t.hostname) && n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid hostname",
				pattern: t.hostname.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			}), t.protocol && !hn(i, t.protocol) && n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid protocol",
				pattern: t.protocol.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			}), n.value = t.normalize ? i.href : pn(r);
			return;
		} catch {
			n.issues.push({
				code: "invalid_format",
				format: "url",
				input: n.value,
				inst: e,
				continue: !t.abort
			});
		}
	};
}), _n = /*@__PURE__*/ T("$ZodEmoji", (e, t) => {
	t.pattern ??= vt(), j.init(e, t);
}), vn = /*@__PURE__*/ T("$ZodNanoID", (e, t) => {
	if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1)) throw Error(`Invalid nanoid length: ${t.length}`);
	t.pattern ??= t.length === void 0 ? dt : ft(t.length), j.init(e, t);
}), yn = /*@__PURE__*/ T("$ZodCUID", (e, t) => {
	t.pattern ??= ot, j.init(e, t);
}), bn = /*@__PURE__*/ T("$ZodCUID2", (e, t) => {
	t.pattern ??= st, j.init(e, t);
}), xn = /*@__PURE__*/ T("$ZodULID", (e, t) => {
	t.pattern ??= ct, j.init(e, t);
}), Sn = /*@__PURE__*/ T("$ZodXID", (e, t) => {
	t.pattern ??= lt, j.init(e, t);
}), Cn = /*@__PURE__*/ T("$ZodKSUID", (e, t) => {
	t.pattern ??= ut, j.init(e, t);
}), wn = /*@__PURE__*/ T("$ZodISODateTime", (e, t) => {
	t.pattern ??= Mt(t), j.init(e, t), (t.local || t.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((e) => {
		e._zod.bag.laxFormat = !0;
	}));
}), Tn = /*@__PURE__*/ T("$ZodISODate", (e, t) => {
	t.pattern ??= kt, j.init(e, t);
}), En = /*@__PURE__*/ T("$ZodISOTime", (e, t) => {
	t.pattern ??= jt(t), j.init(e, t);
}), Dn = /*@__PURE__*/ T("$ZodISODuration", (e, t) => {
	t.pattern ??= pt, j.init(e, t);
}), On = /*@__PURE__*/ T("$ZodIPv4", (e, t) => {
	t.pattern ??= yt, j.init(e, t), e._zod.bag.format = "ipv4";
}), kn = /^[0-9a-fA-F:.]+$/;
function An(e) {
	if (!kn.test(e)) return !1;
	try {
		return new URL(`http://[${e}]`), !0;
	} catch {
		return !1;
	}
}
var jn = /*@__PURE__*/ T("$ZodIPv6", (e, t) => {
	t.pattern ??= bt, j.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
		An(n.value) || n.issues.push({
			code: "invalid_format",
			format: "ipv6",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Mn = /*@__PURE__*/ T("$ZodCIDRv4", (e, t) => {
	t.pattern ??= xt, j.init(e, t);
});
function Nn(e) {
	let t = e.split("/");
	if (t.length !== 2) return !1;
	let [n, r] = t;
	if (!r) return !1;
	let i = Number(r);
	return `${i}` !== r || i < 0 || i > 128 ? !1 : An(n);
}
var Pn = /*@__PURE__*/ T("$ZodCIDRv6", (e, t) => {
	t.pattern ??= St, j.init(e, t), e._zod.check = (n) => {
		Nn(n.value) || n.issues.push({
			code: "invalid_format",
			format: "cidrv6",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function Fn(e) {
	if (e === "") return !0;
	if (/\s/.test(e) || e.length % 4 != 0) return !1;
	try {
		return atob(e), !0;
	} catch {
		return !1;
	}
}
var In = /*@__PURE__*/ T("$ZodBase64", (e, t) => {
	t.pattern ??= Ct, j.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
		Fn(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function Ln(e) {
	if (!wt.test(e)) return !1;
	let t = e.replace(/[-_]/g, (e) => e === "-" ? "+" : "/");
	return Fn(t.padEnd(Math.ceil(t.length / 4) * 4, "="));
}
var Rn = /*@__PURE__*/ T("$ZodBase64URL", (e, t) => {
	t.pattern ??= wt, j.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
		Ln(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64url",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), zn = /*@__PURE__*/ T("$ZodE164", (e, t) => {
	t.pattern ??= Et, j.init(e, t);
});
function Bn(e, t = null) {
	try {
		let n = e.split(".");
		if (n.length !== 3) return !1;
		let [r] = n;
		if (!r) return !1;
		let i = JSON.parse(atob(r));
		return !("typ" in i && i?.typ !== "JWT" || !i.alg || t && (!("alg" in i) || i.alg !== t));
	} catch {
		return !1;
	}
}
var Vn = /*@__PURE__*/ T("$ZodJWT", (e, t) => {
	j.init(e, t), e._zod.check = (n) => {
		Bn(n.value, t.alg) || n.issues.push({
			code: "invalid_format",
			format: "jwt",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Hn = /*@__PURE__*/ T("$ZodNumber", (e, t) => {
	A.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? Ft, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = Number(n.value);
		} catch {}
		let i = n.value;
		if (typeof i == "number" && !Number.isNaN(i) && Number.isFinite(i)) return n;
		let a = typeof i == "number" ? Number.isNaN(i) ? "NaN" : Number.isFinite(i) ? void 0 : String(i) : void 0;
		return n.issues.push({
			expected: "number",
			code: "invalid_type",
			input: i,
			inst: e,
			...a ? { received: a } : {}
		}), n;
	};
}), Un = /*@__PURE__*/ T("$ZodNumberFormat", (e, t) => {
	Wt.init(e, t), Hn.init(e, t);
}), Wn = /*@__PURE__*/ T("$ZodBoolean", (e, t) => {
	A.init(e, t), e._zod.pattern = It, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = !!n.value;
		} catch {}
		let i = n.value;
		return typeof i == "boolean" || n.issues.push({
			expected: "boolean",
			code: "invalid_type",
			input: i,
			inst: e
		}), n;
	};
}), Gn = /*@__PURE__*/ T("$ZodUnknown", (e, t) => {
	A.init(e, t), e._zod.parse = (e) => e;
}), Kn = /*@__PURE__*/ T("$ZodNever", (e, t) => {
	A.init(e, t), e._zod.parse = (t, n) => (t.issues.push({
		expected: "never",
		code: "invalid_type",
		input: t.value,
		inst: e
	}), t);
});
function qn(e, t, n) {
	e.issues.length && t.issues.push(...de(n, e.issues)), t.value[n] = e.value;
}
var Jn = /*@__PURE__*/ T("$ZodArray", (e, t) => {
	A.init(e, t);
	let n = D.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!Array.isArray(a)) return r.issues.push({
			expected: "array",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		r.value = n ? n.alloc(e, r, Array(a.length), i) : Array(a.length);
		let o = [];
		for (let e = 0; e < a.length; e++) {
			let n = a[e], s = t.element._zod.run({
				value: n,
				issues: []
			}, i);
			s instanceof Promise ? o.push(s.then((t) => qn(t, r, e))) : qn(s, r, e);
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
});
function Yn(e, t, n, r, i, a) {
	let o = n in r, s = a === "optional";
	if (o || !s || i !== "optional") {
		if (e.issues.length) {
			if (i !== void 0 && s && !o) return;
			t.issues.push(...de(n, e.issues));
		}
		if (!o && i === void 0) {
			e.issues.length || t.issues.push({
				code: "invalid_type",
				expected: "nonoptional",
				input: void 0,
				path: [n]
			});
			return;
		}
		e.value === void 0 ? o && (t.value[n] = void 0) : t.value[n] = e.value;
	}
}
var Xn = [];
function Zn(e) {
	let t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), r = n.length ? n : Xn, i = r.length ? [...t, ...r] : t;
	for (let t of i) if (!e.shape?.[t]?._zod?.traits?.has("$ZodType")) throw Error(`Invalid element at key "${String(t)}": expected a Zod schema`);
	let a = te(e.shape);
	return {
		...e,
		allKeys: i,
		symbolKeys: r,
		keySet: new Set(t),
		numKeys: t.length,
		optionalKeys: new Set(a)
	};
}
function Qn(e, t, n, r, i, a) {
	let o = [], s = i.keySet, c = i.catchall._zod, l = c.def.type, u = c.optin, d = c.optout;
	for (let i in t) {
		if (s.has(i)) continue;
		if (i === "__proto__") {
			l === "never" && o.push(i);
			continue;
		}
		if (l === "never") {
			o.push(i);
			continue;
		}
		let a = c.run({
			value: t[i],
			issues: []
		}, r);
		a instanceof Promise ? e.push(a.then((e) => Yn(e, n, i, t, u, d))) : Yn(a, n, i, t, u, d);
	}
	return o.length && n.issues.push({
		code: "unrecognized_keys",
		keys: o,
		input: t,
		inst: a,
		continue: !0
	}), e.length ? Promise.all(e).then(() => n) : n;
}
var $n = /* @__PURE__ */ new WeakMap(), er = /*@__PURE__*/ T("$ZodObject", (e, t) => {
	if (A.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
		let e = t.shape;
		$n.set(t, e), Object.defineProperty(t, "shape", { get: () => {
			let n = { ...e };
			return Object.defineProperty(t, "shape", { value: n }), $n.set(t, n), n;
		} });
	}
	let n = r(() => Zn(t));
	w(e, "propValues", (e) => {
		let t = e.def.shape, n = {};
		for (let e in t) {
			let r = t[e]._zod;
			if (r.values) {
				Object.prototype.hasOwnProperty.call(n, e) || s(n, e, /* @__PURE__ */ new Set());
				for (let t of r.values) n[e].add(t);
				r.optin !== void 0 && n[e].add(void 0);
			}
		}
		return n;
	});
	let i = f, a = t.catchall, o, c = D.memoizer;
	c?.attach(e), e._zod.parse = (t, r) => {
		o ??= n.value;
		let s = t.value;
		if (!i(s)) return t.issues.push({
			expected: "object",
			code: "invalid_type",
			input: s,
			inst: e
		}), t;
		t.value = c ? c.alloc(e, t, {}, r) : {};
		let l = [], u = o.shape;
		for (let e of o.allKeys) {
			if (e === "__proto__") continue;
			let n = u[e], i = n._zod.optin, a = n._zod.optout, o = n._zod.run({
				value: s[e],
				issues: []
			}, r);
			o instanceof Promise ? l.push(o.then((n) => Yn(n, t, e, s, i, a))) : Yn(o, t, e, s, i, a);
		}
		return a ? Qn(l, s, t, r, n.value, e) : l.length ? Promise.all(l).then(() => t) : t;
	};
}), tr = /*@__PURE__*/ T("$ZodObjectJIT", (e, t) => {
	er.init(e, t);
	let n = e._zod.parse, i = r(() => Zn(t)), a = D.memoizer, o = (t) => {
		let n = i.value, r = n.symbolKeys, o = new nn(["payload", "ctx"], {
			shape: t,
			inst: e,
			memo: a,
			syms: r
		}), s = (e) => `shape[${e}]._zod.run({ value: input[${e}], issues: [] }, ctx)`, c = (e, t) => `
          for (let i = 0; i < ${e}.issues.length; i++) {
            const iss = ${e}.issues[i];
            iss.path = iss.path ? [${t}, ...iss.path] : [${t}];
            payload.issues.push(iss);
          }`;
		o.write("const input = payload.value;");
		let u = Object.create(null), d = 0;
		for (let e of n.allKeys) u[e] = `key_${d++}`;
		o.write(a ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
		for (let e of n.allKeys) {
			if (e === "__proto__") continue;
			let n = u[e], i = typeof e == "symbol" ? `syms[${r.indexOf(e)}]` : l(e), a = `${i} in input`, d = t[e], f = d?._zod?.optin, p = f !== void 0, m = d?._zod?.optout === "optional";
			if (o.write(`const ${n} = ${s(i)};`), p && m) {
				let e = f === "optional" ? `${n}_present` : `${n}.value !== undefined || ${n}_present`;
				o.write(`
        const ${n}_present = ${a};
        if (!${n}.issues.length || ${n}_present) {
          if (${n}.issues.length) {${c(n, i)}
          }

          if (${e}) {
            newResult[${i}] = ${n}.value;
          }
        }

      `);
			} else p ? o.write(`
        if (${n}.issues.length) {${c(n, i)}
        }
        
        if (${n}.value === undefined) {
          if (${a}) {
            newResult[${i}] = undefined;
          }
        } else {
          newResult[${i}] = ${n}.value;
        }

      `) : o.write(`
        const ${n}_present = ${a};
        if (${n}.issues.length) {${c(n, i)}
        }
        if (!${n}_present && !${n}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${i}]
          });
        }

        if (${n}_present) {
          newResult[${i}] = ${n}.value;
        }

      `);
		}
		return o.write("payload.value = newResult;"), o.write("return payload;"), o.compile();
	}, s, c = f, u = !D.jitless, d = u && p.value, m = t.catchall, h;
	e._zod.parse = (r, a) => {
		h ??= i.value;
		let l = r.value;
		return c(l) ? u && d && a?.async === !1 && a.jitless !== !0 ? (s ||= o(t.shape), r = s(r, a), m ? Qn([], l, r, a, h, e) : r) : n(r, a) : (r.issues.push({
			expected: "object",
			code: "invalid_type",
			input: l,
			inst: e
		}), r);
	};
});
function nr(e, t, n, r) {
	for (let n of e) if (n.issues.length === 0) return t.value = n.value, t;
	let i = e.filter((e) => !b(e));
	return i.length === 1 ? (t.value = i[0].value, i[0]) : (t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: e.map((e) => e.issues.map((e) => x(e, r, O())))
	}), t);
}
var rr = /*@__PURE__*/ T("$ZodUnion", (e, t) => {
	A.init(e, t), w(e, "optin", (e) => e.def.options.some((e) => e._zod.optin === "defaulted") ? "defaulted" : e.def.options.some((e) => e._zod.optin !== void 0) ? "optional" : void 0), w(e, "optout", (e) => e.def.options.some((e) => e._zod.optout === "optional") ? "optional" : void 0), w(e, "values", (e) => {
		if (e.def.options.every((e) => e._zod.values)) return new Set(e.def.options.flatMap((e) => Array.from(e._zod.values)));
	}), w(e, "pattern", (e) => {
		if (e.def.options.every((e) => e._zod.pattern)) {
			let t = e.def.options.map((e) => e._zod.pattern);
			return RegExp(`^(${t.map((e) => a(e.source)).join("|")})$`);
		}
	});
	let n = t.options.length === 1 ? t.options[0]._zod.run : null;
	e._zod.parse = (r, i) => {
		if (n) return n(r, i);
		let a = !1, o = [];
		for (let e of t.options) {
			let t = e._zod.run({
				value: r.value,
				issues: []
			}, i);
			if (t instanceof Promise) o.push(t), a = !0;
			else {
				if (t.issues.length === 0) return t;
				o.push(t);
			}
		}
		return a ? Promise.all(o).then((t) => nr(t, r, e, i)) : nr(o, r, e, i);
	};
}), ir = /*@__PURE__*/ T("$ZodIntersection", (e, t) => {
	A.init(e, t), e._zod.parse = (e, n) => {
		let r = e.value, i = t.left._zod.run({
			value: r,
			issues: []
		}, n), a = t.right._zod.run({
			value: r,
			issues: []
		}, n);
		return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([t, n]) => or(e, t, n)) : or(e, i, a);
	};
});
function ar(e, t) {
	if (e === t || e instanceof Date && t instanceof Date && +e == +t) return {
		valid: !0,
		data: e
	};
	if (m(e) && m(t)) {
		let n = Object.keys(t), r = Object.keys(e).filter((e) => n.indexOf(e) !== -1), i = {
			...e,
			...t
		};
		Object.prototype.hasOwnProperty.call(i, "__proto__") && delete i.__proto__;
		for (let n of r) {
			if (n === "__proto__") continue;
			let r = ar(e[n], t[n]);
			if (!r.valid) return {
				valid: !1,
				mergeErrorPath: [n, ...r.mergeErrorPath]
			};
			i[n] = r.data;
		}
		return {
			valid: !0,
			data: i
		};
	}
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return {
			valid: !1,
			mergeErrorPath: []
		};
		let n = [];
		for (let r = 0; r < e.length; r++) {
			let i = e[r], a = t[r], o = ar(i, a);
			if (!o.valid) return {
				valid: !1,
				mergeErrorPath: [r, ...o.mergeErrorPath]
			};
			n.push(o.data);
		}
		return {
			valid: !0,
			data: n
		};
	}
	return {
		valid: !1,
		mergeErrorPath: []
	};
}
function or(e, t, n) {
	let r = /* @__PURE__ */ new Map(), i, a = /* @__PURE__ */ new Map(), o = (e, t) => {
		let n;
		if (e.code === "unrecognized_keys" && !e.path?.length) i ??= e, n = e.keys;
		else if (e.code === "invalid_key" && e.origin === "record" && e.path?.length === 1) {
			let t = String(e.path[0]);
			a.has(t) || a.set(t, e), n = [t];
		} else return !1;
		for (let e of n) r.has(e) || r.set(e, {}), r.get(e)[t] = !0;
		return !0;
	};
	for (let n of t.issues) o(n, "l") || e.issues.push(n);
	for (let t of n.issues) o(t, "r") || e.issues.push(t);
	let s = [...r].filter(([, e]) => e.l && e.r).map(([e]) => e);
	if (s.length) {
		let t = i ? s.filter((e) => i.keys.includes(e)) : [];
		t.length && e.issues.push({
			...i,
			keys: t
		});
		for (let n of s) !t.includes(n) && a.has(n) && e.issues.push(a.get(n));
	}
	let c = ar(t.value, n.value);
	if (!c.valid) {
		if (b(e)) return e;
		throw Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
	}
	return e.value = c.data, e;
}
var sr = /*@__PURE__*/ T("$ZodEnum", (t, n) => {
	A.init(t, n);
	let r = e(n.entries), i = new Set(r);
	t._zod.values = i;
	let a = r.filter((e) => ee.has(typeof e));
	t._zod.pattern = RegExp(a.length ? `^(${a.map((e) => g(e.toString())).join("|")})$` : "^[^\\s\\S]$"), t._zod.parse = (e, n) => {
		let a = e.value;
		return i.has(a) || e.issues.push({
			code: "invalid_value",
			values: r,
			input: a,
			inst: t
		}), e;
	};
}), cr = /*@__PURE__*/ T("$ZodLiteral", (e, t) => {
	A.init(e, t);
	let n = new Set(t.values);
	e._zod.values = n, e._zod.pattern = RegExp(t.values.length ? `^(${t.values.map((e) => typeof e == "string" ? g(e) : e ? g(e.toString()) : String(e)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (r, i) => {
		let a = r.value;
		return n.has(a) || r.issues.push({
			code: "invalid_value",
			values: t.values,
			input: a,
			inst: e
		}), r;
	};
}), lr = /*@__PURE__*/ T("$ZodTransform", (e, t) => {
	A.init(e, t), e._zod.optin = "optional", D.memoizer?.guard(e), e._zod.parse = (n, r) => {
		if (r.direction === "backward") throw new Me(e.constructor.name);
		let i = t.transform(n.value, n);
		if (r.async) return (i instanceof Promise ? i : Promise.resolve(i)).then((e) => (n.value = e, n));
		if (i instanceof Promise) throw new E();
		return n.value = i, n;
	};
});
function ur(e, t) {
	return e.value = t.issues.length ? void 0 : t.value, e;
}
var dr = /*@__PURE__*/ T("$ZodOptional", (e, t) => {
	A.init(e, t), w(e, "optin", (e) => e.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", w(e, "values", (e) => {
		let t = e.def.innerType._zod.values;
		return t ? /* @__PURE__ */ new Set([...t, void 0]) : void 0;
	}), w(e, "pattern", (e) => {
		let t = e.def.innerType._zod.pattern;
		return t ? RegExp(`^(${a(t.source)})?$`) : void 0;
	}), e._zod.parse = (e, n) => {
		if (e.value === void 0) {
			if (t.innerType._zod.optin !== "defaulted") return e;
			let r = t.innerType._zod.run({
				value: e.value,
				issues: []
			}, n);
			return r instanceof Promise ? r.then((t) => ur(e, t)) : ur(e, r);
		}
		return t.innerType._zod.run(e, n);
	};
}), fr = /*@__PURE__*/ T("$ZodExactOptional", (e, t) => {
	dr.init(e, t), w(e, "values", (e) => e.def.innerType._zod.values), w(e, "pattern", (e) => e.def.innerType._zod.pattern), e._zod.parse = (e, n) => t.innerType._zod.run(e, n);
}), pr = /*@__PURE__*/ T("$ZodNullable", (e, t) => {
	A.init(e, t), w(e, "optin", (e) => e.def.innerType._zod.optin), w(e, "optout", (e) => e.def.innerType._zod.optout), w(e, "pattern", (e) => {
		let t = e.def.innerType._zod.pattern;
		return t ? RegExp(`^(${a(t.source)}|null)$`) : void 0;
	}), w(e, "values", (e) => e.def.innerType._zod.values ? /* @__PURE__ */ new Set([...e.def.innerType._zod.values, null]) : void 0), e._zod.parse = (e, n) => e.value === null ? e : t.innerType._zod.run(e, n);
}), mr = /*@__PURE__*/ T("$ZodDefault", (e, t) => {
	A.init(e, t), e._zod.optin = "defaulted", w(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		if (e.value === void 0) return e.value = t.defaultValue, e;
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => hr(e, t)) : hr(r, t);
	};
});
function hr(e, t) {
	return e.value === void 0 && (e.value = t.defaultValue), e;
}
var gr = /*@__PURE__*/ T("$ZodPrefault", (e, t) => {
	A.init(e, t), e._zod.optin = "defaulted", w(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => (n.direction === "backward" || e.value === void 0 && (e.value = t.defaultValue), t.innerType._zod.run(e, n));
}), _r = /*@__PURE__*/ T("$ZodNonOptional", (e, t) => {
	A.init(e, t), w(e, "values", (e) => {
		let t = e.def.innerType._zod.values;
		return t ? new Set([...t].filter((e) => e !== void 0)) : void 0;
	}), e._zod.parse = (n, r) => {
		let i = t.innerType._zod.run(n, r);
		return i instanceof Promise ? i.then((t) => vr(t, e)) : vr(i, e);
	};
});
function vr(e, t) {
	return !e.issues.length && e.value === void 0 && e.issues.push({
		code: "invalid_type",
		expected: "nonoptional",
		input: e.value,
		inst: t
	}), e;
}
function yr(e, t, n, r) {
	return t.issues.length ? (e.value = n.catchValue({
		...t,
		value: e.value,
		error: { issues: t.issues.map((e) => x(e, r, O())) },
		input: e.value
	}), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
var br = /*@__PURE__*/ T("$ZodCatch", (e, t) => {
	A.init(e, t), w(e, "optin", (e) => e.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), w(e, "optout", (e) => e.def.innerType._zod.optout), w(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run({
			value: e.value,
			issues: []
		}, n);
		return r instanceof Promise ? r.then((r) => yr(e, r, t, n)) : yr(e, r, t, n);
	};
}), xr = /*@__PURE__*/ T("$ZodPipe", (e, t) => {
	A.init(e, t), w(e, "values", (e) => e.def.in._zod.values), w(e, "optin", (e) => e.def.in._zod.optin), w(e, "optout", (e) => e.def.out._zod.optout), w(e, "propValues", (e) => e.def.in._zod.propValues), e._zod.parse = (e, n) => {
		if (n.direction === "backward") {
			let r = t.out._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => Sr(e, t.in, n)) : Sr(r, t.in, n);
		}
		let r = t.in._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => Sr(e, t.out, n)) : Sr(r, t.out, n);
	};
});
function Sr(e, t, n) {
	return e.issues.some((e) => e.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({
		value: e.value,
		issues: e.issues
	}, n);
}
var Cr = /*@__PURE__*/ T("$ZodReadonly", (e, t) => {
	A.init(e, t), w(e, "propValues", (e) => e.def.innerType._zod.propValues), w(e, "values", (e) => e.def.innerType._zod.values), w(e, "optin", (e) => e.def.innerType?._zod?.optin), w(e, "optout", (e) => e.def.innerType?._zod?.optout), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then(wr) : wr(r);
	};
});
function wr(e) {
	return e.memo || (e.value = Object.freeze(e.value)), e;
}
var Tr = /*@__PURE__*/ T("$ZodCustom", (e, t) => {
	k.init(e, t), A.init(e, t), e._zod.parse = (e, t) => e, e._zod.check = (n) => {
		let r = n.value, i = t.fn(r);
		if (i instanceof Promise) return i.then((t) => Er(t, n, r, e));
		Er(i, n, r, e);
	};
});
function Er(e, t, n, r) {
	if (!e) {
		let e = {
			code: "custom",
			input: n,
			inst: r,
			path: [...r._zod.def.path ?? []],
			continue: !r._zod.def.abort
		};
		r._zod.def.params && (e.params = r._zod.def.params), t.issues.push(ve(e));
	}
}
//#endregion
//#region node_modules/zod/v4/core/memoizer.js
var Dr = class extends Error {
	constructor() {
		super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
	}
}, Or = "~memo", kr = [];
function Ar(e) {
	return e.map((e) => e.path ? {
		...e,
		path: e.path.slice()
	} : { ...e });
}
var jr = /*@__PURE__*/ new WeakMap();
function Mr(e, t) {
	let n = jr.get(e);
	if (n !== void 0) return n;
	if (t.has(e)) return !0;
	t.add(e);
	let r = !1, i = (e) => {
		!r && e?._zod && Mr(e, t) && (r = !0);
	}, a = e._zod.def;
	switch (a.type) {
		case "object":
			for (let e of Reflect.ownKeys(a.shape)) i(a.shape[e]);
			i(a.catchall);
			break;
		case "array":
			i(a.element);
			break;
		case "tuple":
			for (let e of a.items) i(e);
			i(a.rest);
			break;
		case "record":
		case "map":
			i(a.keyType), i(a.valueType);
			break;
		case "set":
			i(a.valueType);
			break;
		case "union":
			for (let e of a.options) i(e);
			break;
		case "intersection":
			i(a.left), i(a.right);
			break;
		case "optional":
		case "nullable":
		case "default":
		case "prefault":
		case "catch":
		case "readonly":
		case "nonoptional":
		case "promise":
		case "success":
			i(a.innerType);
			break;
		case "pipe":
			i(a.in), i(a.out);
			break;
		case "function":
			i(a.input), i(a.output);
			break;
		case "lazy":
			i(e._zod.innerType);
			break;
		case "template_literal":
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "bigint":
		case "symbol":
		case "undefined":
		case "null":
		case "void":
		case "never":
		case "any":
		case "unknown":
		case "date":
		case "nan":
		case "enum":
		case "literal":
		case "file":
		case "transform":
		case "custom": break;
		default: for (let e in a) {
			let t = Object.getOwnPropertyDescriptor(a, e);
			if (!t || t.get) continue;
			let n = t.value;
			if (n && typeof n == "object") {
				if (n._zod) i(n);
				else if (Array.isArray(n)) for (let e of n) i(e);
			}
		}
	}
	return t.delete(e), jr.set(e, r), r;
}
function Nr(e, t) {
	let n = e.buckets.get(t);
	return n || (n = /* @__PURE__ */ new Map(), e.buckets.set(t, n)), n;
}
var Pr, Fr = [], Ir = {
	alloc(e, t, n) {
		let r = Pr;
		if (!r) return n;
		Pr = void 0;
		let i = {
			value: n,
			issues: null
		};
		return r.set(t.value, i), Fr.push(i), n;
	},
	guard(e) {
		var t;
		(t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
			let t = e._zod.parse, n = (e, n) => {
				if (n.direction !== "backward" && Rr(n, e.value)) throw new Dr();
				return t(e, n);
			};
			e._zod.parse = n, e._zod.run === t && (e._zod.run = n);
		});
	},
	attach(e) {
		var t;
		let n, r, i;
		(t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
			let t = e._zod.parse, a = (o, s) => {
				if (n === void 0 && (n = Mr(e, /* @__PURE__ */ new Set()), !n)) return e._zod.parse = t, e._zod.run === a && (e._zod.run = t), t(o, s);
				let c = o.value;
				if (typeof c != "object" || !c) return t(o, s);
				let l = s[Or];
				l || (l = {
					buckets: /* @__PURE__ */ new Map(),
					backEdges: void 0
				}, s[Or] = l);
				let u;
				r === s ? u = i : (u = Nr(l, e), r = s, i = u);
				let d = u.get(c);
				if (d) return o.value = d.value, d.issues ? d.issues.length && o.issues.push(...Ar(d.issues)) : (o.memo = !0, l.backEdges ?? (l.backEdges = /* @__PURE__ */ new Set()), l.backEdges.add(d.value)), o;
				Pr = u;
				let f = Fr.length, p = t(o, s);
				Pr = void 0;
				let m = Fr.length > f ? Fr.pop() : void 0;
				return p instanceof Promise ? p.then((e) => (m && (m.issues = e.issues.length ? Ar(e.issues) : kr), e)) : (m && (m.issues = p.issues.length ? Ar(p.issues) : kr), p);
			};
			e._zod.parse = a, e._zod.run === t && (e._zod.run = a);
		});
	}
};
function Lr() {
	return Ir;
}
function Rr(e, t) {
	let n = e[Or]?.backEdges;
	return n !== void 0 && typeof t == "object" && !!t && n.has(t);
}
//#endregion
//#region node_modules/zod/v4/locales/en.js
var zr = () => {
	let e = {
		string: {
			unit: "characters",
			verb: "to have"
		},
		file: {
			unit: "bytes",
			verb: "to have"
		},
		array: {
			unit: "items",
			verb: "to have"
		},
		set: {
			unit: "items",
			verb: "to have"
		},
		map: {
			unit: "entries",
			verb: "to have"
		}
	};
	function n(t) {
		return e[t] ?? null;
	}
	let r = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		credit_card: "credit card number",
		jwt: "JWT",
		template_literal: "input"
	}, i = { nan: "NaN" };
	function a(e, t) {
		return e === "number" && typeof t == "number" && !Number.isFinite(t) ? String(t) : i[e] ?? e;
	}
	return (e) => {
		switch (e.code) {
			case "invalid_type": return `Invalid input: expected ${a(e.expected)}, received ${a(_e(e.input), e.input)}`;
			case "invalid_value": return e.values.length === 1 ? `Invalid input: expected ${y(e.values[0])}` : `Invalid option: expected one of ${t(e.values, "|")}`;
			case "too_big": {
				let t = e.exact ? "exactly " : e.inclusive ? "<=" : "<", r = n(e.origin);
				return r ? `Too big: expected ${e.origin ?? "value"} to have ${t}${e.maximum.toString()} ${r.unit ?? "elements"}` : `Too big: expected ${e.origin ?? "value"} to be ${t}${e.maximum.toString()}`;
			}
			case "too_small": {
				let t = e.exact ? "exactly " : e.inclusive ? ">=" : ">", r = n(e.origin);
				return r ? `Too small: expected ${e.origin} to have ${t}${e.minimum.toString()} ${r.unit}` : `Too small: expected ${e.origin} to be ${t}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Invalid string: must start with "${t.prefix}"` : t.format === "ends_with" ? `Invalid string: must end with "${t.suffix}"` : t.format === "includes" ? `Invalid string: must include "${t.includes}"` : t.format === "regex" ? `Invalid string: must match pattern ${t.pattern}` : `Invalid ${r[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Invalid number: must be a multiple of ${e.divisor}`;
			case "unrecognized_keys": return `Unrecognized key${e.keys.length > 1 ? "s" : ""}: ${t(e.keys, ", ")}`;
			case "invalid_key": return `Invalid key in ${e.origin}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `Invalid discriminator value. Expected ${e.options.map((e) => `'${e}'`).join(" | ")}` : e.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
			case "invalid_element": return `Invalid value in ${e.origin}`;
			default: return "Invalid input";
		}
	};
};
function Br() {
	return { localeError: zr() };
}
//#endregion
//#region node_modules/zod/v4/core/registries.js
var Vr, Hr = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
	}
	add(e, ...t) {
		let n = t[0];
		return this._map.set(e, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, e), this;
	}
	clear() {
		return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
	}
	remove(e) {
		let t = this._map.get(e);
		return t && typeof t == "object" && "id" in t && this._idmap.delete(t.id), this._map.delete(e), this;
	}
	get(e) {
		let t = e._zod.parent;
		if (t) {
			let n = { ...this.get(t) ?? {} };
			delete n.id;
			let r = {
				...n,
				...this._map.get(e)
			};
			return Object.keys(r).length ? r : void 0;
		}
		return this._map.get(e);
	}
	has(e) {
		return this._map.has(e);
	}
};
function Ur() {
	return new Hr();
}
(Vr = globalThis).__zod_globalRegistry ?? (Vr.__zod_globalRegistry = Ur());
var Wr = globalThis.__zod_globalRegistry;
//#endregion
//#region node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Gr(e, t) {
	return new e({
		type: "string",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Kr(e, t) {
	return new e({
		type: "string",
		format: "email",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function qr(e, t) {
	return new e({
		type: "string",
		format: "guid",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Jr(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Yr(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v4",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Xr(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v6",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Zr(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v7",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Qr(e, t) {
	return new e({
		type: "string",
		format: "url",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function $r(e, t) {
	return new e({
		type: "string",
		format: "emoji",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ei(e, t) {
	return new e({
		type: "string",
		format: "nanoid",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ti(e, t) {
	return new e({
		type: "string",
		format: "cuid",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ni(e, t) {
	return new e({
		type: "string",
		format: "cuid2",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ri(e, t) {
	return new e({
		type: "string",
		format: "ulid",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ii(e, t) {
	return new e({
		type: "string",
		format: "xid",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ai(e, t) {
	return new e({
		type: "string",
		format: "ksuid",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function oi(e, t) {
	return new e({
		type: "string",
		format: "ipv4",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function si(e, t) {
	return new e({
		type: "string",
		format: "ipv6",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ci(e, t) {
	return new e({
		type: "string",
		format: "cidrv4",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function li(e, t) {
	return new e({
		type: "string",
		format: "cidrv6",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ui(e, t) {
	return new e({
		type: "string",
		format: "base64",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function di(e, t) {
	return new e({
		type: "string",
		format: "base64url",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function fi(e, t) {
	return new e({
		type: "string",
		format: "e164",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function pi(e, t) {
	return new e({
		type: "string",
		format: "jwt",
		check: "string_format",
		abort: !1,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function mi(e, t) {
	return new e({
		type: "string",
		format: "datetime",
		check: "string_format",
		offset: !1,
		local: !1,
		precision: null,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function hi(e, t) {
	return new e({
		type: "string",
		format: "date",
		check: "string_format",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function gi(e, t) {
	return new e({
		type: "string",
		format: "time",
		check: "string_format",
		precision: null,
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function _i(e, t) {
	return new e({
		type: "string",
		format: "duration",
		check: "string_format",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function vi(e, t) {
	return new e({
		type: "number",
		checks: [],
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function yi(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "safeint",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function bi(e, t) {
	return new e({
		type: "boolean",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function xi(e) {
	return new e({ type: "unknown" });
}
// @__NO_SIDE_EFFECTS__
function Si(e, t) {
	return new e({
		type: "never",
		...v(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ci(e, t) {
	return new Vt({
		check: "less_than",
		...v(t),
		value: e,
		inclusive: !1
	});
}
// @__NO_SIDE_EFFECTS__
function wi(e, t) {
	return new Vt({
		check: "less_than",
		...v(t),
		value: e,
		inclusive: !0
	});
}
// @__NO_SIDE_EFFECTS__
function Ti(e, t) {
	return new Ht({
		check: "greater_than",
		...v(t),
		value: e,
		inclusive: !1
	});
}
// @__NO_SIDE_EFFECTS__
function Ei(e, t) {
	return new Ht({
		check: "greater_than",
		...v(t),
		value: e,
		inclusive: !0
	});
}
// @__NO_SIDE_EFFECTS__
function Di(e, t) {
	return new Ut({
		check: "multiple_of",
		...v(t),
		value: e
	});
}
// @__NO_SIDE_EFFECTS__
function Oi(e, t) {
	return new Gt({
		check: "max_length",
		...v(t),
		maximum: e
	});
}
// @__NO_SIDE_EFFECTS__
function ki(e, t) {
	return new Kt({
		check: "min_length",
		...v(t),
		minimum: e
	});
}
// @__NO_SIDE_EFFECTS__
function Ai(e, t) {
	return new qt({
		check: "length_equals",
		...v(t),
		length: e
	});
}
// @__NO_SIDE_EFFECTS__
function ji(e, t) {
	return new Yt({
		check: "string_format",
		format: "regex",
		...v(t),
		pattern: e
	});
}
// @__NO_SIDE_EFFECTS__
function Mi(e) {
	return new Xt({
		check: "string_format",
		format: "lowercase",
		...v(e)
	});
}
// @__NO_SIDE_EFFECTS__
function Ni(e) {
	return new Zt({
		check: "string_format",
		format: "uppercase",
		...v(e)
	});
}
// @__NO_SIDE_EFFECTS__
function Pi(e, t) {
	return new Qt({
		check: "string_format",
		format: "includes",
		...v(t),
		includes: e
	});
}
// @__NO_SIDE_EFFECTS__
function Fi(e, t) {
	return new $t({
		check: "string_format",
		format: "starts_with",
		...v(t),
		prefix: e
	});
}
// @__NO_SIDE_EFFECTS__
function Ii(e, t) {
	return new en({
		check: "string_format",
		format: "ends_with",
		...v(t),
		suffix: e
	});
}
// @__NO_SIDE_EFFECTS__
function M(e) {
	return new tn({
		check: "overwrite",
		tx: e
	});
}
// @__NO_SIDE_EFFECTS__
function Li(e) {
	return /* @__PURE__ */ M((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function Ri() {
	return /* @__PURE__ */ M((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function zi() {
	return /* @__PURE__ */ M((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function Bi() {
	return /* @__PURE__ */ M((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function Vi() {
	return /* @__PURE__ */ M((e) => u(e));
}
// @__NO_SIDE_EFFECTS__
function Hi(e, t, n) {
	return new e({
		type: "array",
		element: t,
		...v(n)
	});
}
// @__NO_SIDE_EFFECTS__
function Ui(e, t, n) {
	return new e({
		type: "custom",
		check: "custom",
		fn: t,
		...v(n)
	});
}
// @__NO_SIDE_EFFECTS__
function Wi(e, t) {
	let n = /* @__PURE__ */ Gi((t) => (t.addIssue = (e) => {
		if (typeof e == "string") t.issues.push(ve(e, t.value, n._zod.def));
		else {
			let r = e;
			r.fatal && (r.continue = !1), r.code ??= "custom", "input" in r || (r.input = t.value), r.inst ??= n, r.continue ??= !n._zod.def.abort, t.issues.push(ve(r));
		}
	}, e(t.value, t)), t);
	return n;
}
// @__NO_SIDE_EFFECTS__
function Gi(e, t) {
	let n = new k({
		check: "custom",
		...v(t)
	});
	return n._zod.check = e, n;
}
//#endregion
//#region node_modules/zod/v4/core/to-json-schema.js
function N(e, ...t) {
	for (let n of t) for (let t of Reflect.ownKeys(n)) Object.prototype.propertyIsEnumerable.call(n, t) && s(e, t, n[t]);
	return e;
}
function Ki(e) {
	let t = e?.target ?? "draft-2020-12";
	return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
		processors: e.processors ?? {},
		metadataRegistry: e?.metadata ?? Wr,
		target: t,
		unrepresentable: e?.unrepresentable ?? "throw",
		override: e?.override ?? (() => {}),
		io: e?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		sharedDefsExtractedFor: void 0,
		sharedEmitDoneFor: void 0,
		cycles: e?.cycles ?? "ref",
		reused: e?.reused ?? "inline",
		intersections: [],
		deferred: [],
		external: e?.external ?? void 0
	};
}
function P(e, t, n, r, i) {
	let a = typeof t.unrepresentable == "function" ? t.unrepresentable({
		zodSchema: e,
		path: r.path,
		message: i
	}) : t.unrepresentable;
	if (a === "any") return !1;
	if (a === void 0 || a === "throw") throw Error(i);
	return Object.assign(n, a), !0;
}
function F(e, t, n = {
	path: [],
	schemaPath: []
}) {
	var r;
	let i = e._zod.def, a = t.seen.get(e);
	if (a) return a.count++, n.schemaPath.includes(e) && (a.cycle = n.path), a.schema;
	let o = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: n.path
	};
	t.seen.set(e, o), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
	let s = e._zod.toJSONSchema?.();
	if (s) o.schema = s;
	else {
		let r = {
			...n,
			schemaPath: [...n.schemaPath, e],
			path: n.path
		};
		if (e._zod.processJSONSchema) e._zod.processJSONSchema(t, o.schema, r);
		else {
			let n = o.schema, a = t.processors[i.type];
			if (!a) throw Error(`[toJSONSchema]: Non-representable type encountered: ${i.type}`);
			a(e, t, n, r);
		}
		let a = e._zod.parent;
		a && (o.ref ||= a, F(a, t, r), t.seen.get(a).isParent = !0);
	}
	let c = t.metadataRegistry.get(e);
	return c && N(o.schema, c), t.io === "input" && I(e) && (delete o.schema.examples, delete o.schema.default), t.io === "input" && "_prefault" in o.schema && ((r = o.schema).default ?? (r.default = o.schema._prefault)), delete o.schema._prefault, t.seen.get(e).schema;
}
function qi(e) {
	return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function Ji(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	if (e.external && e.sharedDefsExtractedFor === e.external) return;
	let r = /* @__PURE__ */ new Map();
	for (let t of e.seen.entries()) {
		let n = e.metadataRegistry.get(t[0])?.id;
		if (n) {
			let e = r.get(n);
			if (e && e !== t[0]) throw Error(`Duplicate schema id "${n}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			r.set(n, t[0]);
		}
	}
	let i = (t) => {
		let r = e.target === "draft-2020-12" ? "$defs" : "definitions";
		if (e.external) {
			let n = e.external.registry.get(t[0])?.id, i = e.external.uri ?? ((e) => e);
			if (n) return { ref: i(n) };
			let a = t[1].defId ?? t[1].schema.id ?? `schema${e.counter++}`;
			return t[1].defId = a, {
				defId: a,
				ref: `${i("__shared")}#/${r}/${qi(a)}`
			};
		}
		let i = `#/${r}/`;
		if (t[1] === n && !t[1].schema.id) return { ref: "#" };
		let a = t[1].schema.id ?? `__schema${e.counter++}`;
		return {
			defId: a,
			ref: i + qi(a)
		};
	}, a = (e) => {
		if (e[1].schema.$ref) return;
		let t = e[1], { ref: n, defId: r } = i(e);
		t.def = { ...t.schema }, r && (t.defId = r);
		let a = t.schema;
		for (let e in a) delete a[e];
		a.$ref = n;
	};
	if (e.cycles === "throw") for (let t of e.seen.entries()) {
		let e = t[1];
		if (e.cycle) throw Error(`Cycle detected: #/${e.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (let n of e.seen.entries()) {
		let r = n[1];
		if (t === n[0]) {
			a(n);
			continue;
		}
		if (e.external) {
			let r = e.external.registry.get(n[0])?.id;
			if (t !== n[0] && r) {
				a(n);
				continue;
			}
		}
		if (e.metadataRegistry.get(n[0])?.id) {
			a(n);
			continue;
		}
		if (r.cycle) {
			a(n);
			continue;
		}
		if (r.count > 1 && e.reused === "ref") {
			a(n);
			continue;
		}
	}
	e.external && (e.sharedDefsExtractedFor = e.external);
}
function Yi(e) {
	let t = e.anyOf;
	if (!Array.isArray(t) || t.length === 0 || e.type !== void 0) return;
	let n = [];
	for (let e of t) {
		if (!e || typeof e != "object") return;
		Yi(e);
		let t = Object.keys(e);
		if (t.length !== 1 || t[0] !== "type") return;
		let r = e.type;
		for (let e of Array.isArray(r) ? r : [r]) {
			if (typeof e != "string") return;
			n.includes(e) || n.push(e);
		}
	}
	delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
var Xi = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties"
]), Zi = ["oneOf", "anyOf"];
function Qi(e) {
	let t = e.additionalProperties;
	return t === void 0 || t === !1 || typeof t != "object" || !t ? null : Object.keys(t).length ? t : null;
}
function $i(e) {
	let t = [];
	for (let n of e) {
		if (typeof n != "object" || n.type !== "object") return null;
		for (let e in n) if (!Xi.has(e)) return null;
		t.push(n);
	}
	let n = {}, r = /* @__PURE__ */ new Set();
	for (let e of t) {
		for (let r in e.properties) {
			if (Object.prototype.hasOwnProperty.call(n, r)) continue;
			let e = [];
			for (let n of t) {
				let t = n.properties?.[r] ?? Qi(n);
				t != null && (e.some((e) => JSON.stringify(e) === JSON.stringify(t)) || e.push(t));
			}
			s(n, r, e.length === 1 ? e[0] : $i(e) ?? { allOf: e });
		}
		for (let t of e.required ?? []) r.add(t);
	}
	let i = {
		type: "object",
		properties: n
	};
	if (r.size && (i.required = [...r]), t.every((e) => e.additionalProperties === !1)) i.additionalProperties = !1;
	else {
		let e = [];
		for (let n of t) {
			let t = Qi(n);
			t && !e.some((e) => JSON.stringify(e) === JSON.stringify(t)) && e.push(t);
		}
		e.length === 1 ? i.additionalProperties = e[0] : e.length > 1 && (i.additionalProperties = { allOf: e });
	}
	return i;
}
function ea(e) {
	let t = e.allOf;
	if (!Array.isArray(t) || t.length < 2) return;
	for (let t of Xi) if (t in e) return;
	let n = t.filter((e) => Zi.some((t) => Array.isArray(e[t]))), r = null;
	if (!n.length) r = $i(t);
	else {
		let e = n[0], i = Zi.find((t) => Array.isArray(e[t]));
		if (Object.keys(e).length !== 1) return;
		let a = t.filter((t) => t !== e), o = e[i].map((e) => $i([...a, e]));
		if (o.some((e) => !e)) return;
		r = { [i]: o };
	}
	r && (delete e.allOf, N(e, r));
}
function ta(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	let r = (t) => {
		let n = e.seen.get(t);
		if (n.ref === null) return;
		let i = n.def ?? n.schema, a = { ...i }, o = n.ref;
		if (n.ref = null, o) {
			r(o);
			let n = e.seen.get(o), s = n.schema;
			if (s.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (i.allOf = i.allOf ?? [], i.allOf.push(s)) : N(i, s), N(i, a), t._zod.parent === o) for (let e in i) e !== "$ref" && e !== "allOf" && (e in a || delete i[e]);
			if (s.$ref && n.def) for (let e in i) e !== "$ref" && e !== "allOf" && e in n.def && JSON.stringify(i[e]) === JSON.stringify(n.def[e]) && delete i[e];
		}
		let s = t._zod.parent;
		if (s && s !== o) {
			r(s);
			let t = e.seen.get(s);
			if (t?.schema.$ref && (i.$ref = t.schema.$ref, t.def)) for (let e in i) e !== "$ref" && e !== "allOf" && e in t.def && JSON.stringify(i[e]) === JSON.stringify(t.def[e]) && delete i[e];
		}
		e.override({
			zodSchema: t,
			jsonSchema: i,
			path: n.path ?? []
		});
	};
	if (!e.external || e.sharedEmitDoneFor !== e.external) {
		for (let t of [...e.seen.entries()].reverse()) r(t[0]);
		if (e.target !== "openapi-3.0") for (let t of e.seen.entries()) Yi(t[1].def ?? t[1].schema);
		for (let t of e.deferred) t();
		if (e.intersections.length) {
			let t = /* @__PURE__ */ new Map();
			for (let n of e.seen.values()) for (let e of [n.schema, n.def]) {
				let n = e?.allOf;
				if (!Array.isArray(n)) continue;
				let r = t.get(n);
				r ? r.push(e) : t.set(n, [e]);
			}
			for (let n of e.intersections) for (let e of t.get(n) ?? []) ea(e);
		}
	}
	let i = {};
	if (e.target === "draft-2020-12" ? i.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? i.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? i.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
		let n = e.external.registry.get(t)?.id;
		if (!n) throw Error("Schema is missing an `id` property");
		i.$id = e.external.uri(n);
	}
	N(i, n.defId ? n.schema : n.def ?? n.schema);
	let a = e.metadataRegistry.get(t)?.id;
	a !== void 0 && i.id === a && delete i.id;
	let o = e.external?.defs ?? {};
	if (!e.external || e.sharedEmitDoneFor !== e.external) for (let t of e.seen.entries()) {
		let e = t[1];
		e.def && e.defId && (e.def.id === e.defId && delete e.def.id, s(o, e.defId, e.def));
	}
	e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(o).length > 0 && (e.target === "draft-2020-12" ? i.$defs = o : i.definitions = o);
	try {
		let n = JSON.parse(JSON.stringify(i));
		return Object.defineProperty(n, "~standard", {
			value: {
				...t["~standard"],
				jsonSchema: {
					input: ra(t, "input", e.processors),
					output: ra(t, "output", e.processors)
				}
			},
			enumerable: !1,
			writable: !1
		}), n;
	} catch {
		throw Error("Error converting schema to JSON.");
	}
}
function I(e, t) {
	let n = t ?? { seen: /* @__PURE__ */ new Set() };
	if (n.seen.has(e)) return !1;
	n.seen.add(e);
	let r = e._zod.def;
	if (r.type === "transform") return !0;
	if (r.type === "array") return I(r.element, n);
	if (r.type === "set") return I(r.valueType, n);
	if (r.type === "lazy") return I(r.getter(), n);
	if (r.type === "promise" || r.type === "optional" || r.type === "nonoptional" || r.type === "nullable" || r.type === "readonly" || r.type === "default" || r.type === "prefault" || r.type === "catch") return I(r.innerType, n);
	if (r.type === "intersection") return I(r.left, n) || I(r.right, n);
	if (r.type === "record" || r.type === "map") return I(r.keyType, n) || I(r.valueType, n);
	if (r.type === "pipe") return e._zod.traits.has("$ZodCodec") ? !0 : I(r.in, n) || I(r.out, n);
	if (r.type === "object") {
		for (let e in r.shape) if (I(r.shape[e], n)) return !0;
		return !1;
	}
	if (r.type === "union") {
		for (let e of r.options) if (I(e, n)) return !0;
		return !1;
	}
	if (r.type === "tuple") {
		for (let e of r.items) if (I(e, n)) return !0;
		return !!(r.rest && I(r.rest, n));
	}
	return !1;
}
var na = (e, t = {}) => (n) => {
	let r = Ki({
		...n,
		processors: t
	});
	return F(e, r), Ji(r, e), ta(r, e);
}, ra = (e, t, n = {}) => (r) => {
	let { libraryOptions: i, target: a } = r ?? {}, o = Ki({
		...i ?? {},
		target: a,
		io: t,
		processors: n
	});
	return F(e, o), Ji(o, e), ta(o, e);
}, ia = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
}, aa = (e, t, n, r) => {
	let i = n;
	i.type = "string";
	let { minimum: a, maximum: o, format: s, patterns: c, contentEncoding: l, laxFormat: u } = e._zod.bag;
	if (typeof a == "number" && (i.minLength = a), typeof o == "number" && (i.maxLength = o), s && (i.format = ia[s] ?? s, i.format === "" && delete i.format, (s === "time" || u) && delete i.format), l && (i.contentEncoding = l), c && c.size > 0) {
		let e = [...c];
		e.length === 1 ? i.pattern = e[0].source : e.length > 1 && (i.allOf = [...e.map((e) => ({
			...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: e.source
		}))]);
	}
}, oa = (e, t, n, r) => {
	let i = n, { minimum: a, maximum: o, format: s, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: u } = e._zod.bag;
	i.type = typeof s == "string" && s.includes("int") ? "integer" : "number";
	let d = typeof u == "number" && u >= (a ?? -Infinity), f = typeof l == "number" && l <= (o ?? Infinity), p = t.target === "draft-04" || t.target === "openapi-3.0";
	d ? p ? (i.minimum = u, i.exclusiveMinimum = !0) : i.exclusiveMinimum = u : typeof a == "number" && (i.minimum = a), f ? p ? (i.maximum = l, i.exclusiveMaximum = !0) : i.exclusiveMaximum = l : typeof o == "number" && (i.maximum = o), typeof c == "number" && (Number.isFinite(c) && c !== 0 ? i.multipleOf = Math.abs(c) : P(e, t, i, r, `A multipleOf divisor of ${c} cannot be represented in JSON Schema`));
}, sa = (e, t, n, r) => {
	n.type = "boolean";
}, ca = (e, t, n, r) => {
	n.not = {};
}, la = (t, n, r, i) => {
	let a = t._zod.def, o = e(a.entries);
	if (o.length === 0) {
		r.not = {};
		return;
	}
	o.every((e) => typeof e == "number") && (r.type = "number"), o.every((e) => typeof e == "string") && (r.type = "string"), r.enum = o;
}, ua = (e, t, n, r) => {
	let i = e._zod.def;
	if (i.values.length === 0) {
		n.not = {};
		return;
	}
	let a = [];
	for (let o of i.values) if (o === void 0) {
		if (P(e, t, n, r, "Literal `undefined` cannot be represented in JSON Schema")) return;
	} else if (typeof o == "bigint") {
		if (P(e, t, n, r, "BigInt literals cannot be represented in JSON Schema")) return;
		a.push(Number(o));
	} else a.push(o);
	if (a.length !== 0) {
		if (a.length === 1) {
			let e = a[0];
			n.type = e === null ? "null" : typeof e, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [e] : n.const = e;
		} else a.every((e) => typeof e == "number") && (n.type = "number"), a.every((e) => typeof e == "string") && (n.type = "string"), a.every((e) => typeof e == "boolean") && (n.type = "boolean"), a.every((e) => e === null) && (n.type = "null"), n.enum = a;
	}
}, da = (e, t, n, r) => {
	P(e, t, n, r, "Custom types cannot be represented in JSON Schema");
}, fa = (e, t, n, r) => {
	P(e, t, n, r, "Transforms cannot be represented in JSON Schema");
}, pa = (e, t, n, r) => {
	let i = n, a = e._zod.def, { minimum: o, maximum: s } = e._zod.bag;
	typeof o == "number" && (i.minItems = o), typeof s == "number" && (i.maxItems = s), i.type = "array", i.items = F(a.element, t, {
		...r,
		path: [...r.path, "items"]
	});
};
function ma(e) {
	let t = e._zod.def;
	return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? ma(t.out) : t.type === "catch" ? ma(t.innerType) : e._zod.optin;
}
var ha = (e, t, n, r) => {
	let i = n, a = e._zod.def, o = a.shape;
	if (Object.getOwnPropertySymbols(o).length && P(e, t, i, r, "Symbol keys cannot be represented in JSON Schema")) return;
	i.type = "object", i.properties = {};
	for (let e in o) s(i.properties, e, F(o[e], t, {
		...r,
		path: [
			...r.path,
			"properties",
			e
		]
	}));
	let c = new Set(Object.keys(o)), l = new Set([...c].filter((e) => {
		let n = a.shape[e];
		return t.io === "input" ? ma(n) === void 0 : n._zod.optout === void 0;
	}));
	l.size > 0 && (i.required = Array.from(l)), a.catchall?._zod.def.type === "never" ? i.additionalProperties = !1 : a.catchall ? a.catchall && (i.additionalProperties = F(a.catchall, t, {
		...r,
		path: [...r.path, "additionalProperties"]
	})) : t.io === "output" && (i.additionalProperties = !1);
}, ga = (e, t, n, r) => {
	let i = e._zod.def, a = i.inclusive === !1, o = i.options.map((e, n) => F(e, t, {
		...r,
		path: [
			...r.path,
			a ? "oneOf" : "anyOf",
			n
		]
	}));
	a ? n.oneOf = o : n.anyOf = o;
}, _a = (e, t, n, r) => {
	let i = e._zod.def, a = F(i.left, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			0
		]
	}), o = F(i.right, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			1
		]
	}), s = (e) => "allOf" in e && Object.keys(e).length === 1, c = [...s(a) ? a.allOf : [a], ...s(o) ? o.allOf : [o]];
	n.allOf = c, t.intersections.push(c);
}, va = (e, t, n, r) => {
	let i = e._zod.def, a = F(i.innerType, t, r), o = t.seen.get(e);
	t.target === "openapi-3.0" ? (o.ref = i.innerType, n.nullable = !0) : n.anyOf = [a, { type: "null" }];
}, ya = (e, t, n, r) => {
	let i = e._zod.def;
	F(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, ba = Symbol();
function xa(e, t, n, r, i) {
	let a = !1, o = JSON.stringify(e, (e, t) => typeof t == "bigint" ? (a = !0, null) : t);
	return a ? (P(t, n, r, i, "BigInt defaults cannot be represented in JSON Schema"), ba) : JSON.parse(o);
}
var Sa = (e, t, n, r) => {
	let i = e._zod.def;
	F(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o = xa(i.defaultValue, e, t, n, r);
	o !== ba && (n.default = o);
}, Ca = (e, t, n, r) => {
	let i = e._zod.def;
	F(i.innerType, t, r);
	let a = t.seen.get(e);
	if (a.ref = i.innerType, t.io !== "input") return;
	let o = xa(i.defaultValue, e, t, n, r);
	o !== ba && (n._prefault = o);
}, wa = (e, t, n, r) => {
	let i = e._zod.def;
	F(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o;
	try {
		o = i.catchValue(void 0);
	} catch {
		P(e, t, n, r, "Dynamic catch values are not supported in JSON Schema");
		return;
	}
	n.default = o;
}, Ta = (e, t, n, r) => {
	let i = e._zod.def, a = i.in._zod.traits.has("$ZodTransform"), o = t.io === "input" ? a ? i.out : i.in : i.out;
	F(o, t, r);
	let s = t.seen.get(e);
	s.ref = o;
}, Ea = (e, t, n, r) => {
	let i = e._zod.def;
	F(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType, n.readOnly = !0;
}, Da = (e, t, n, r) => {
	let i = e._zod.def;
	F(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, Oa = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function ka(e, t, n) {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		get() {
			let e = n(this);
			return Object.defineProperty(this, t, {
				value: e,
				configurable: !0,
				writable: !0
			}), e;
		},
		set(e) {
			Object.defineProperty(this, t, {
				value: e,
				configurable: !0,
				writable: !0
			});
		}
	});
}
var L = /*@__PURE__*/ T("ZodError", (e, t) => {
	Be.init(e, t), e.name = "ZodError";
	let r = Object.getPrototypeOf(e);
	Oa.has(r) || (Oa.add(r), ka(r, "format", (e) => (t) => We(e, t)), ka(r, "flatten", (e) => (t) => Ue(e, t)), ka(r, "addIssue", (e) => (t) => {
		e.issues.push(t), e.message = JSON.stringify(e.issues, n, 2);
	}), ka(r, "addIssues", (e) => (t) => {
		e.issues.push(...t), e.message = JSON.stringify(e.issues, n, 2);
	}), Object.defineProperty(r, "isEmpty", {
		configurable: !0,
		enumerable: !1,
		get() {
			return this.issues.length === 0;
		}
	}));
}, void 0, { Parent: Error }), Aa = /* @__PURE__ */ Ke(L), ja = /* @__PURE__ */ qe(L), Ma = /* @__PURE__ */ Je(L), Na = /* @__PURE__ */ Xe(L), Pa = /* @__PURE__ */ Qe(L), Fa = /* @__PURE__ */ $e(L), Ia = /* @__PURE__ */ et(L), La = /* @__PURE__ */ tt(L), Ra = /* @__PURE__ */ nt(L), za = /* @__PURE__ */ rt(L), Ba = /* @__PURE__ */ it(L), Va = /* @__PURE__ */ at(L);
//#endregion
//#region node_modules/zod/v4/classic/schemas.js
function Ha() {
	D.localeError || O(Br());
}
function Ua() {
	D.memoizer || O({ memoizer: Lr() });
}
var R = /*@__PURE__*/ T("ZodType", (e, t) => (Ha(), A.init(e, t), e.def = t, e.type = t.type, e), {
	check(...e) {
		let t = this.def;
		return this.clone(c(t, { checks: [...t.checks ?? [], ...e.map((e) => typeof e == "function" ? { _zod: {
			check: e,
			def: { check: "custom" },
			onattach: []
		} } : e)] }), { parent: !0 });
	},
	with(...e) {
		return this.check(...e);
	},
	clone(e, t) {
		return _(this, e, t);
	},
	brand() {
		return this;
	},
	register(e, t) {
		return e.add(this, t), this;
	},
	refine(e, t) {
		return this.check(is(e, t));
	},
	superRefine(e, t) {
		return this.check(as(e, t));
	},
	overwrite(e) {
		return this.check(/* @__PURE__ */ M(e));
	},
	optional() {
		return Bo(this);
	},
	exactOptional() {
		return Ho(this);
	},
	nullable() {
		return Wo(this);
	},
	nullish() {
		return Bo(Wo(this));
	},
	nonoptional(e) {
		return Xo(this, e);
	},
	array() {
		return Oo(this);
	},
	or(e) {
		return jo([this, e]);
	},
	and(e) {
		return No(this, e);
	},
	transform(e) {
		return es(this, Ro(e));
	},
	default(e) {
		return Ko(this, e);
	},
	prefault(e) {
		return Jo(this, e);
	},
	catch(e) {
		return Qo(this, e);
	},
	pipe(e) {
		return es(this, e);
	},
	readonly() {
		return ns(this);
	},
	describe(e) {
		let t = this.clone();
		return Wr.add(t, { description: e }), t;
	},
	meta(...e) {
		if (e.length === 0) return Wr.get(this);
		let t = this.clone();
		return Wr.add(t, e[0]), t;
	},
	isOptional() {
		return this.safeParse(void 0).success;
	},
	isNullable() {
		return this.safeParse(null).success;
	},
	apply(e, ...t) {
		return t.length === 0 ? e(this) : e(this, ...t);
	},
	get "~standard"() {
		return be(this, "~standard", {
			...on(this),
			jsonSchema: {
				input: ra(this, "input"),
				output: ra(this, "output")
			}
		});
	},
	set "~standard"(e) {
		S(this, "~standard", e);
	},
	parse: function e(t, n) {
		return Aa(this, t, n, { callee: e });
	},
	parseAsync: async function e(t, n) {
		return await ja(this, t, n, { callee: e });
	},
	safeParse(e, t) {
		return Ma(this, e, t);
	},
	async safeParseAsync(e, t) {
		return Na(this, e, t);
	},
	get spa() {
		return this?.safeParseAsync;
	},
	set spa(e) {
		S(this, "spa", e);
	},
	encode: function e(t, n) {
		return Pa(this, t, n, { callee: e });
	},
	decode: function e(t, n) {
		return Fa(this, t, n, { callee: e });
	},
	encodeAsync: async function e(t, n) {
		return await Ia(this, t, n, { callee: e });
	},
	decodeAsync: async function e(t, n) {
		return await La(this, t, n, { callee: e });
	},
	safeEncode(e, t) {
		return Ra(this, e, t);
	},
	safeDecode(e, t) {
		return za(this, e, t);
	},
	async safeEncodeAsync(e, t) {
		return Ba(this, e, t);
	},
	async safeDecodeAsync(e, t) {
		return Va(this, e, t);
	},
	toJSONSchema(e) {
		return na(this, {})(e);
	},
	get description() {
		return Wr.get(this)?.description;
	},
	get _def() {
		return this._zod.def;
	}
}), Wa = /*@__PURE__*/ T("_ZodString", (e, t) => {
	sn.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => aa(e, t, n, r);
	let n = e._zod.bag;
	e.format = n.format ?? null, e.minLength = n.minimum ?? null, e.maxLength = n.maximum ?? null;
}, {
	regex(...e) {
		return this.check(/* @__PURE__ */ ji(...e));
	},
	includes(...e) {
		return this.check(/* @__PURE__ */ Pi(...e));
	},
	startsWith(...e) {
		return this.check(/* @__PURE__ */ Fi(...e));
	},
	endsWith(...e) {
		return this.check(/* @__PURE__ */ Ii(...e));
	},
	min(...e) {
		return this.check(/* @__PURE__ */ ki(...e));
	},
	max(...e) {
		return this.check(/* @__PURE__ */ Oi(...e));
	},
	length(...e) {
		return this.check(/* @__PURE__ */ Ai(...e));
	},
	nonempty(...e) {
		return this.check(/* @__PURE__ */ ki(1, ...e));
	},
	lowercase(e) {
		return this.check(/* @__PURE__ */ Mi(e));
	},
	uppercase(e) {
		return this.check(/* @__PURE__ */ Ni(e));
	},
	trim() {
		return this.check(/* @__PURE__ */ Ri());
	},
	normalize(...e) {
		return this.check(/* @__PURE__ */ Li(...e));
	},
	toLowerCase() {
		return this.check(/* @__PURE__ */ zi());
	},
	toUpperCase() {
		return this.check(/* @__PURE__ */ Bi());
	},
	slugify() {
		return this.check(/* @__PURE__ */ Vi());
	}
}), Ga = /*@__PURE__*/ T("ZodString", (e, t) => {
	sn.init(e, t), Wa.init(e, t);
}, {
	email(e) {
		return this.check(/* @__PURE__ */ Kr(Xa, e));
	},
	url(e) {
		return this.check(/* @__PURE__ */ Qr(eo, e));
	},
	jwt(e) {
		return this.check(/* @__PURE__ */ pi(go, e));
	},
	emoji(e) {
		return this.check(/* @__PURE__ */ $r(to, e));
	},
	guid(e) {
		return this.check(/* @__PURE__ */ qr(Za, e));
	},
	uuid(e) {
		return this.check(/* @__PURE__ */ Jr(Qa, e));
	},
	uuidv4(e) {
		return this.check(/* @__PURE__ */ Yr(Qa, e));
	},
	uuidv6(e) {
		return this.check(/* @__PURE__ */ Xr(Qa, e));
	},
	uuidv7(e) {
		return this.check(/* @__PURE__ */ Zr(Qa, e));
	},
	nanoid(e) {
		return this.check(/* @__PURE__ */ ei(no, e));
	},
	cuid(e) {
		return this.check(/* @__PURE__ */ ti(ro, e));
	},
	cuid2(e) {
		return this.check(/* @__PURE__ */ ni(io, e));
	},
	ulid(e) {
		return this.check(/* @__PURE__ */ ri(ao, e));
	},
	base64(e) {
		return this.check(/* @__PURE__ */ ui(po, e));
	},
	base64url(e) {
		return this.check(/* @__PURE__ */ di(mo, e));
	},
	xid(e) {
		return this.check(/* @__PURE__ */ ii(oo, e));
	},
	ksuid(e) {
		return this.check(/* @__PURE__ */ ai(so, e));
	},
	ipv4(e) {
		return this.check(/* @__PURE__ */ oi(co, e));
	},
	ipv6(e) {
		return this.check(/* @__PURE__ */ si(lo, e));
	},
	cidrv4(e) {
		return this.check(/* @__PURE__ */ ci(uo, e));
	},
	cidrv6(e) {
		return this.check(/* @__PURE__ */ li(fo, e));
	},
	e164(e) {
		return this.check(/* @__PURE__ */ fi(ho, e));
	},
	datetime(e) {
		return this.check(/* @__PURE__ */ mi(Ka, e));
	},
	date(e) {
		return this.check(/* @__PURE__ */ hi(qa, e));
	},
	time(e) {
		return this.check(/* @__PURE__ */ gi(Ja, e));
	},
	duration(e) {
		return this.check(/* @__PURE__ */ _i(Ya, e));
	}
});
function z(e) {
	return /* @__PURE__ */ Gr(Ga, e);
}
var B = /*@__PURE__*/ T("ZodStringFormat", (e, t) => {
	j.init(e, t), Wa.init(e, t);
}), Ka = /*@__PURE__*/ T("ZodISODateTime", (e, t) => {
	wn.init(e, t), B.init(e, t);
}), qa = /*@__PURE__*/ T("ZodISODate", (e, t) => {
	Tn.init(e, t), B.init(e, t);
}), Ja = /*@__PURE__*/ T("ZodISOTime", (e, t) => {
	En.init(e, t), B.init(e, t);
}), Ya = /*@__PURE__*/ T("ZodISODuration", (e, t) => {
	Dn.init(e, t), B.init(e, t);
}), Xa = /*@__PURE__*/ T("ZodEmail", (e, t) => {
	un.init(e, t), B.init(e, t);
}), Za = /*@__PURE__*/ T("ZodGUID", (e, t) => {
	cn.init(e, t), B.init(e, t);
}), Qa = /*@__PURE__*/ T("ZodUUID", (e, t) => {
	ln.init(e, t), B.init(e, t);
});
function $a(e) {
	return /* @__PURE__ */ Jr(Qa, e);
}
var eo = /*@__PURE__*/ T("ZodURL", (e, t) => {
	gn.init(e, t), B.init(e, t);
}), to = /*@__PURE__*/ T("ZodEmoji", (e, t) => {
	_n.init(e, t), B.init(e, t);
}), no = /*@__PURE__*/ T("ZodNanoID", (e, t) => {
	vn.init(e, t), B.init(e, t);
}), ro = /*@__PURE__*/ T("ZodCUID", (e, t) => {
	yn.init(e, t), B.init(e, t);
}), io = /*@__PURE__*/ T("ZodCUID2", (e, t) => {
	bn.init(e, t), B.init(e, t);
}), ao = /*@__PURE__*/ T("ZodULID", (e, t) => {
	xn.init(e, t), B.init(e, t);
}), oo = /*@__PURE__*/ T("ZodXID", (e, t) => {
	Sn.init(e, t), B.init(e, t);
}), so = /*@__PURE__*/ T("ZodKSUID", (e, t) => {
	Cn.init(e, t), B.init(e, t);
}), co = /*@__PURE__*/ T("ZodIPv4", (e, t) => {
	On.init(e, t), B.init(e, t);
}), lo = /*@__PURE__*/ T("ZodIPv6", (e, t) => {
	jn.init(e, t), B.init(e, t);
}), uo = /*@__PURE__*/ T("ZodCIDRv4", (e, t) => {
	Mn.init(e, t), B.init(e, t);
}), fo = /*@__PURE__*/ T("ZodCIDRv6", (e, t) => {
	Pn.init(e, t), B.init(e, t);
}), po = /*@__PURE__*/ T("ZodBase64", (e, t) => {
	In.init(e, t), B.init(e, t);
}), mo = /*@__PURE__*/ T("ZodBase64URL", (e, t) => {
	Rn.init(e, t), B.init(e, t);
}), ho = /*@__PURE__*/ T("ZodE164", (e, t) => {
	zn.init(e, t), B.init(e, t);
}), go = /*@__PURE__*/ T("ZodJWT", (e, t) => {
	Vn.init(e, t), B.init(e, t);
}), _o = /*@__PURE__*/ T("ZodNumber", (e, t) => {
	Hn.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => oa(e, t, n, r);
	let n = e._zod.bag;
	e.minValue = Math.max(n.minimum ?? -Infinity, n.exclusiveMinimum ?? -Infinity) ?? null, e.maxValue = Math.min(n.maximum ?? Infinity, n.exclusiveMaximum ?? Infinity) ?? null, e.isInt = (n.format ?? "").includes("int") || Number.isSafeInteger(n.multipleOf ?? .5), e.isFinite = !0, e.format = n.format ?? null;
}, {
	gt(e, t) {
		return this.check(/* @__PURE__ */ Ti(e, t));
	},
	gte(e, t) {
		return this.check(/* @__PURE__ */ Ei(e, t));
	},
	min(e, t) {
		return this.check(/* @__PURE__ */ Ei(e, t));
	},
	lt(e, t) {
		return this.check(/* @__PURE__ */ Ci(e, t));
	},
	lte(e, t) {
		return this.check(/* @__PURE__ */ wi(e, t));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ wi(e, t));
	},
	int(e) {
		return this.check(bo(e));
	},
	safe(e) {
		return this.check(bo(e));
	},
	positive(e) {
		return this.check(/* @__PURE__ */ Ti(0, e));
	},
	nonnegative(e) {
		return this.check(/* @__PURE__ */ Ei(0, e));
	},
	negative(e) {
		return this.check(/* @__PURE__ */ Ci(0, e));
	},
	nonpositive(e) {
		return this.check(/* @__PURE__ */ wi(0, e));
	},
	multipleOf(e, t) {
		return this.check(/* @__PURE__ */ Di(e, t));
	},
	step(e, t) {
		return this.check(/* @__PURE__ */ Di(e, t));
	},
	finite() {
		return this;
	}
});
function vo(e) {
	return /* @__PURE__ */ vi(_o, e);
}
var yo = /*@__PURE__*/ T("ZodNumberFormat", (e, t) => {
	Un.init(e, t), _o.init(e, t);
});
function bo(e) {
	return /* @__PURE__ */ yi(yo, e);
}
var xo = /*@__PURE__*/ T("ZodBoolean", (e, t) => {
	Wn.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => sa(e, t, n, r);
});
function So(e) {
	return /* @__PURE__ */ bi(xo, e);
}
var Co = /*@__PURE__*/ T("ZodUnknown", (e, t) => {
	Gn.init(e, t), R.init(e, t), e._zod.processJSONSchema = (e, t, n) => void 0;
});
function wo() {
	return /* @__PURE__ */ xi(Co);
}
var To = /*@__PURE__*/ T("ZodNever", (e, t) => {
	Kn.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => ca(e, t, n, r);
});
function Eo(e) {
	return /* @__PURE__ */ Si(To, e);
}
var Do = /*@__PURE__*/ T("ZodArray", (e, t) => {
	Ua(), Jn.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => pa(e, t, n, r), e.element = t.element;
}, {
	min(e, t) {
		return this.check(/* @__PURE__ */ ki(e, t));
	},
	nonempty(e) {
		return this.check(/* @__PURE__ */ ki(1, e));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ Oi(e, t));
	},
	length(e, t) {
		return this.check(/* @__PURE__ */ Ai(e, t));
	},
	unwrap() {
		return this.element;
	}
});
function Oo(e, t) {
	return /* @__PURE__ */ Hi(Do, e, t);
}
var ko = /*@__PURE__*/ T("ZodObject", (e, t) => {
	Ua(), tr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => ha(e, t, n, r), Te(e, "shape", (e) => e._zod.def.shape, !1);
}, {
	keyof() {
		return H(Object.keys(this._zod.def.shape));
	},
	catchall(e) {
		return this.clone({
			...this._zod.def,
			catchall: e
		});
	},
	passthrough() {
		return this.clone({
			...this._zod.def,
			catchall: wo()
		});
	},
	loose() {
		return this.clone({
			...this._zod.def,
			catchall: wo()
		});
	},
	strict() {
		return this.clone({
			...this._zod.def,
			catchall: Eo()
		});
	},
	strip() {
		return this.clone({
			...this._zod.def,
			catchall: void 0
		});
	},
	extend(e) {
		return ae(this, e);
	},
	safeExtend(e) {
		return oe(this, e);
	},
	merge(e) {
		return se(this, e);
	},
	pick(e) {
		return re(this, e);
	},
	omit(e) {
		return ie(this, e);
	},
	partial(...e) {
		return ce(zo, this, e[0]);
	},
	exactPartial(...e) {
		return ce(Vo, this, e[0], "exactPartial");
	},
	required(...e) {
		return le(Yo, this, e[0]);
	}
});
function V(e, t) {
	return new ko({
		type: "object",
		shape: e,
		catchall: Eo(),
		...v(t)
	});
}
var Ao = /*@__PURE__*/ T("ZodUnion", (e, t) => {
	rr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => ga(e, t, n, r), e.options = t.options;
});
function jo(e, t) {
	return new Ao({
		type: "union",
		options: e,
		...v(t)
	});
}
var Mo = /*@__PURE__*/ T("ZodIntersection", (e, t) => {
	ir.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => _a(e, t, n, r);
});
function No(e, t) {
	return new Mo({
		type: "intersection",
		left: e,
		right: t
	});
}
var Po = /*@__PURE__*/ T("ZodEnum", (e, t) => {
	sr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => la(e, t, n, r), e.enum = t.entries, e.options = Object.values(t.entries);
	let n = new Set(Object.keys(t.entries));
	e.extract = (e, r) => {
		let i = {};
		for (let r of e) if (n.has(r)) i[r] = t.entries[r];
		else throw Error(`Key ${r} not found in enum`);
		return new Po({
			...t,
			checks: [],
			...v(r),
			entries: i
		});
	}, e.exclude = (e, r) => {
		let i = { ...t.entries };
		for (let t of e) if (n.has(t)) delete i[t];
		else throw Error(`Key ${t} not found in enum`);
		return new Po({
			...t,
			checks: [],
			...v(r),
			entries: i
		});
	};
});
function H(e, t) {
	return new Po({
		type: "enum",
		entries: Array.isArray(e) ? Object.fromEntries(e.map((e) => [e, e])) : e,
		...v(t)
	});
}
var Fo = /*@__PURE__*/ T("ZodLiteral", (e, t) => {
	cr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => ua(e, t, n, r), e.values = new Set(t.values), Object.defineProperty(e, "value", { get() {
		if (t.values.length > 1) throw Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return t.values[0];
	} });
});
function Io(e, t) {
	return new Fo({
		type: "literal",
		values: Array.isArray(e) ? e : [e],
		...v(t)
	});
}
var Lo = /*@__PURE__*/ T("ZodTransform", (e, t) => {
	Ua(), lr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => fa(e, t, n, r), e._zod.parse = (n, r) => {
		if (r.direction === "backward") throw new Me(e.constructor.name);
		n.addIssue = (r) => {
			if (typeof r == "string") n.issues.push(ve(r, n.value, t));
			else {
				let t = r;
				t.fatal && (t.continue = !1), t.code ??= "custom", "input" in t || (t.input = n.value), t.inst ??= e, n.issues.push(ve(t));
			}
		};
		let i = t.transform(n.value, n);
		return i instanceof Promise ? i.then((e) => (n.value = e, n)) : (n.value = i, n);
	};
});
function Ro(e) {
	return new Lo({
		type: "transform",
		transform: e
	});
}
var zo = /*@__PURE__*/ T("ZodOptional", (e, t) => {
	dr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => Da(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Bo(e) {
	return new zo({
		type: "optional",
		innerType: e
	});
}
var Vo = /*@__PURE__*/ T("ZodExactOptional", (e, t) => {
	fr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => Da(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Ho(e) {
	return new Vo({
		type: "optional",
		innerType: e
	});
}
var Uo = /*@__PURE__*/ T("ZodNullable", (e, t) => {
	pr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => va(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Wo(e) {
	return new Uo({
		type: "nullable",
		innerType: e
	});
}
var Go = /*@__PURE__*/ T("ZodDefault", (e, t) => {
	mr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => Sa(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Ko(e, t) {
	return new Go({
		type: "default",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : h(t);
		}
	});
}
var qo = /*@__PURE__*/ T("ZodPrefault", (e, t) => {
	gr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ca(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Jo(e, t) {
	return new qo({
		type: "prefault",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : h(t);
		}
	});
}
var Yo = /*@__PURE__*/ T("ZodNonOptional", (e, t) => {
	_r.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => ya(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Xo(e, t) {
	return new Yo({
		type: "nonoptional",
		innerType: e,
		...v(t)
	});
}
var Zo = /*@__PURE__*/ T("ZodCatch", (e, t) => {
	br.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => wa(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Qo(e, t) {
	return new Zo({
		type: "catch",
		innerType: e,
		catchValue: typeof t == "function" ? t : De(t)
	});
}
var $o = /*@__PURE__*/ T("ZodPipe", (e, t) => {
	xr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ta(e, t, n, r), e.in = t.in, e.out = t.out;
});
function es(e, t) {
	return new $o({
		type: "pipe",
		in: e,
		out: t
	});
}
var ts = /*@__PURE__*/ T("ZodReadonly", (e, t) => {
	Cr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ea(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function ns(e) {
	return new ts({
		type: "readonly",
		innerType: e
	});
}
var rs = /*@__PURE__*/ T("ZodCustom", (e, t) => {
	Tr.init(e, t), R.init(e, t), e._zod.processJSONSchema = (t, n, r) => da(e, t, n, r);
});
function is(e, t = {}) {
	return /* @__PURE__ */ Ui(rs, e, t);
}
function as(e, t) {
	return /* @__PURE__ */ Wi(e, t);
}
//#endregion
//#region src/shared/validation.ts
var U = $a(), W = vo().int().nonnegative(), os = V({}), ss = V({
	origin: z().max(4096),
	location: z().max(4096),
	locationMode: H(["origin_path", "origin_only"]),
	title: z().max(256).nullable()
}), cs = V({
	clientFileId: U,
	name: z().min(1).max(1024),
	byteLength: W.max(2 ** 53 - 1),
	declaredMime: z().max(256),
	lastModified: W.nullable()
}), ls = {
	sessionId: U,
	token: z().min(43).max(44)
}, us = V({
	recordId: U,
	expectedRevision: W
}), ds = {
	CAPTURE_HELLO: os,
	CAPTURE_BEGIN: V({
		batchEventId: U,
		source: Io("standard_input"),
		page: ss,
		files: Oo(cs).min(1).max(1)
	}),
	CAPTURE_CHUNK: V({
		...ls,
		index: W.max(200),
		rawLength: W.min(1).max(262144),
		base64: z().max(349528),
		chunkSha256: z().regex(/^[a-f0-9]{64}$/)
	}),
	CAPTURE_FINISH: V(ls),
	CAPTURE_RESUME: V(ls),
	CAPTURE_ABORT: V({
		...ls,
		reason: H([
			"read_failed",
			"source_changed",
			"source_gone",
			"user_cancelled"
		])
	}),
	CAPTURE_SOURCE_GONE: V({ batchEventIds: Oo(U).max(100) }),
	UI_GET_RUNTIME_STATE: os,
	UI_GET_SITE_STATUS: V({ origin: z().max(4096) }),
	UI_SET_SITE_POLICY: V({
		origin: z().max(4096),
		enabled: So(),
		dropEnabled: Io(!1),
		locationMode: H(["origin_path", "origin_only"]),
		saveTitle: So()
	}),
	UI_SET_GLOBAL_PAUSE: V({ paused: So() }),
	UI_SET_SUBMISSION: V({
		records: Oo(us).min(1).max(100),
		state: H([
			"unknown",
			"user_confirmed",
			"user_reported_failed",
			"user_reported_cancelled"
		]),
		note: z().max(4e3).nullable()
	})
}, fs = V({
	v: Io(1),
	requestId: U,
	vaultEpoch: W.nullable(),
	type: H(Object.keys(ds)),
	payload: wo()
});
function ps(e) {
	if (new TextEncoder().encode(JSON.stringify(e)).length > 524288) throw Error("E_MESSAGE_TOO_LARGE");
	let t = fs.parse(e);
	return {
		...t,
		payload: ds[t.type].parse(t.payload)
	};
}
//#endregion
//#region node_modules/idb/build/index.js
var ms = (e, t) => t.some((t) => e instanceof t), hs, gs;
function _s() {
	return hs ||= [
		IDBDatabase,
		IDBObjectStore,
		IDBIndex,
		IDBCursor,
		IDBTransaction
	];
}
function vs() {
	return gs ||= [
		IDBCursor.prototype.advance,
		IDBCursor.prototype.continue,
		IDBCursor.prototype.continuePrimaryKey
	];
}
var ys = /* @__PURE__ */ new WeakMap(), bs = /* @__PURE__ */ new WeakMap(), xs = /* @__PURE__ */ new WeakMap();
function Ss(e) {
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("success", i), e.removeEventListener("error", a);
		}, i = () => {
			t(G(e.result)), r();
		}, a = () => {
			n(e.error), r();
		};
		e.addEventListener("success", i), e.addEventListener("error", a);
	});
	return xs.set(t, e), t;
}
function Cs(e) {
	if (ys.has(e)) return;
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("complete", i), e.removeEventListener("error", a), e.removeEventListener("abort", a);
		}, i = () => {
			t(), r();
		}, a = () => {
			n(e.error || new DOMException("AbortError", "AbortError")), r();
		};
		e.addEventListener("complete", i), e.addEventListener("error", a), e.addEventListener("abort", a);
	});
	ys.set(e, t);
}
var ws = {
	get(e, t, n) {
		if (e instanceof IDBTransaction) {
			if (t === "done") return ys.get(e);
			if (t === "store") return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
		}
		return G(e[t]);
	},
	set(e, t, n) {
		return e[t] = n, !0;
	},
	has(e, t) {
		return e instanceof IDBTransaction && (t === "done" || t === "store") || t in e;
	}
};
function Ts(e) {
	ws = e(ws);
}
function Es(e) {
	return vs().includes(e) ? function(...t) {
		return e.apply(Os(this), t), G(this.request);
	} : function(...t) {
		return G(e.apply(Os(this), t));
	};
}
function Ds(e) {
	return typeof e == "function" ? Es(e) : (e instanceof IDBTransaction && Cs(e), ms(e, _s()) ? new Proxy(e, ws) : e);
}
function G(e) {
	if (e instanceof IDBRequest) return Ss(e);
	if (bs.has(e)) return bs.get(e);
	let t = Ds(e);
	return t !== e && (bs.set(e, t), xs.set(t, e)), t;
}
var Os = (e) => xs.get(e);
function ks(e, t, { blocked: n, upgrade: r, blocking: i, terminated: a } = {}) {
	let o = indexedDB.open(e, t), s = G(o);
	return r && o.addEventListener("upgradeneeded", (e) => {
		r(G(o.result), e.oldVersion, e.newVersion, G(o.transaction), e);
	}), n && o.addEventListener("blocked", (e) => n(e.oldVersion, e.newVersion, e)), s.then((e) => {
		a && e.addEventListener("close", () => a()), i && e.addEventListener("versionchange", (e) => i(e.oldVersion, e.newVersion, e));
	}).catch(() => {}), s;
}
var As = [
	"get",
	"getKey",
	"getAll",
	"getAllKeys",
	"count"
], js = [
	"put",
	"add",
	"delete",
	"clear"
], Ms = /* @__PURE__ */ new Map();
function Ns(e, t) {
	if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string")) return;
	if (Ms.get(t)) return Ms.get(t);
	let n = t.replace(/FromIndex$/, ""), r = t !== n, i = js.includes(n);
	if (!(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(i || As.includes(n))) return;
	let a = async function(e, ...t) {
		let a = this.transaction(e, i ? "readwrite" : "readonly"), o = a.store;
		return r && (o = o.index(t.shift())), (await Promise.all([o[n](...t), i && a.done]))[0];
	};
	return Ms.set(t, a), a;
}
Ts((e) => ({
	...e,
	get: (t, n, r) => Ns(t, n) || e.get(t, n, r),
	has: (t, n) => !!Ns(t, n) || e.has(t, n)
}));
var Ps = [
	"continue",
	"continuePrimaryKey",
	"advance"
], Fs = {}, Is = /* @__PURE__ */ new WeakMap(), Ls = /* @__PURE__ */ new WeakMap(), Rs = { get(e, t) {
	if (!Ps.includes(t)) return e[t];
	let n = Fs[t];
	return n ||= Fs[t] = function(...e) {
		Is.set(this, Ls.get(this)[t](...e));
	}, n;
} };
async function* zs(...e) {
	let t = this;
	if (t instanceof IDBCursor || (t = await t.openCursor(...e)), !t) return;
	t = t;
	let n = new Proxy(t, Rs);
	for (Ls.set(n, t), xs.set(n, Os(t)); t;) yield n, t = await (Is.get(n) || t.continue()), Is.delete(n);
}
function Bs(e, t) {
	return t === Symbol.asyncIterator && ms(e, [
		IDBIndex,
		IDBObjectStore,
		IDBCursor
	]) || t === "iterate" && ms(e, [IDBIndex, IDBObjectStore]);
}
Ts((e) => ({
	...e,
	get(t, n, r) {
		return Bs(t, n) ? zs : e.get(t, n, r);
	},
	has(t, n) {
		return Bs(t, n) || e.has(t, n);
	}
}));
//#endregion
//#region src/storage/db.ts
var Vs = [
	"records",
	"objects",
	"chunks",
	"sessions",
	"sites",
	"meta",
	"batches",
	"audit"
], Hs = {
	vaultEpoch: 0,
	globalPolicyEpoch: 0,
	paused: !1,
	clearing: !1,
	settingsRevision: 0,
	budgetBytes: 1073741824
};
function K() {
	return ks("upload-ledger", 1, {
		upgrade(e) {
			e.createObjectStore("records", { keyPath: "recordId" }), e.createObjectStore("objects", { keyPath: "sha256" }), e.createObjectStore("chunks", { keyPath: ["payloadId", "index"] }), e.createObjectStore("sessions", { keyPath: "sessionId" }), e.createObjectStore("sites", { keyPath: "exactOrigin" }), e.createObjectStore("meta"), e.createObjectStore("batches", { keyPath: "key" }), e.createObjectStore("audit", { keyPath: "eventId" });
		},
		blocking(e, t, n) {
			n.target.close();
		}
	});
}
async function q(e) {
	let t = await K(), n = t.transaction(Vs, "readwrite");
	try {
		let t = await e(n);
		return await n.done, t;
	} catch (e) {
		try {
			n.abort();
		} catch {}
		throw await n.done.catch(() => {}), e;
	} finally {
		t.close();
	}
}
async function J(e) {
	return await e.objectStore("meta").get("runtime") ?? { ...Hs };
}
//#endregion
//#region node_modules/@noble/hashes/_u64.js
var Us = (e) => e / 2 ** 32 | 0, Ws = (e) => e >>> 0;
function Gs(e, t, n, r) {
	let i = Us(n), a = Ws(n);
	e.setUint32(t, r ? a : i, r), e.setUint32(t + 4, r ? i : a, r);
}
//#endregion
//#region node_modules/@noble/hashes/utils.js
function Ks(e) {
	return e instanceof Uint8Array || ArrayBuffer.isView(e) && e.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in e && e.BYTES_PER_ELEMENT === 1;
}
var qs = (e) => e ? `"${e}" ` : "";
function Js(e, t = "") {
	if (typeof e != "number") throw TypeError(qs(t) + "expected number, got " + typeof e);
	if (!Number.isSafeInteger(e) || e < 0) throw RangeError(qs(t) + "expected integer >= 0, got " + e);
	return e;
}
function Ys(e, t, n = "") {
	if (Ks(e) && (t === void 0 || e.length === t)) return e;
	t !== void 0 && Js(t, "length");
	let r = Ks(e), i = t === void 0 ? "" : ` of length ${t}`, a = r ? `length=${e.length}` : `type=${typeof e}`, o = qs(n) + "expected Uint8Array" + i + ", got " + a;
	throw r ? RangeError(o) : TypeError(o);
}
var Xs = (e, t) => {
	if (typeof e != "object" || !e || Array.isArray(e)) throw TypeError((t === "object" ? "" : `"${t}" `) + "expected object, got type=" + typeof e);
}, Zs = (e, t) => {
	Xs(e, t);
	let n = Object.getPrototypeOf(e);
	if (n !== Object.prototype && n !== null) throw TypeError(`"${t}" expected plain object`);
	if (Object.hasOwn(e, "__proto__")) throw TypeError(`"${t}.__proto__" is not allowed`);
};
function Qs(e, t = !0) {
	if (e.destroyed) throw Error("hash was destroyed");
	if (t && e.finished) throw Error("digest() was already called");
}
function $s(e, t) {
	Ys(e, void 0, "output");
	let n = t.outputLen;
	if (!(e.length >= n)) throw RangeError("\"output\" expected length >= " + n);
}
function ec(...e) {
	for (let t = 0; t < e.length; t++) e[t].fill(0);
}
function tc(e) {
	return new DataView(e.buffer, e.byteOffset, e.byteLength);
}
function Y(e, t) {
	return e << 32 - t | e >>> t;
}
function nc(e, t, n = "opts") {
	return Zs(e, "defaults"), t !== void 0 && Zs(t, n), Object.assign(Object.create(null), e, t);
}
function rc(e, t = {}) {
	if (typeof e != "function") throw TypeError("\"hashCons\" expected function, got type=" + typeof e);
	t = nc({}, t, "info");
	let n = (t, n) => e(n).update(t).digest(), r = e(void 0);
	return n.outputLen = r.outputLen, n.blockLen = r.blockLen, n.canXOF = r.canXOF, n.create = (t) => e(t), Object.assign(n, t), Object.freeze(n);
}
var ic = (e) => ({ oid: Uint8Array.from([
	6,
	9,
	96,
	134,
	72,
	1,
	101,
	3,
	4,
	2,
	e
]) });
//#endregion
//#region node_modules/@noble/hashes/_md.js
function ac(e, t, n) {
	return e & t ^ ~e & n;
}
function oc(e, t, n) {
	return e & t ^ e & n ^ t & n;
}
var sc = class {
	blockLen;
	outputLen;
	canXOF = !1;
	padOffset;
	isLE;
	buffer;
	view;
	finished = !1;
	length = 0;
	pos = 0;
	destroyed = !1;
	constructor(e, t, n, r) {
		this.blockLen = e, this.outputLen = t, this.padOffset = n, this.isLE = r, this.buffer = new Uint8Array(e), this.view = tc(this.buffer);
	}
	update(e) {
		Qs(this), Ys(e);
		let { view: t, buffer: n, blockLen: r } = this, i = e.length, a = !1;
		for (let o = 0; o < i;) {
			let s = Math.min(r - this.pos, i - o);
			if (s === r) {
				let t = tc(e);
				for (; r <= i - o; o += r) this.process(t, o);
				a = !0;
				continue;
			}
			n.set(o === 0 && s === i ? e : e.subarray(o, o + s), this.pos), this.pos += s, o += s, this.pos === r && (this.process(t, 0), this.pos = 0, a = !0);
		}
		return this.length += e.length, a && this.roundClean(), this;
	}
	digestInto(e) {
		Qs(this), $s(e, this), this.finished = !0;
		let { buffer: t, view: n, blockLen: r, isLE: i } = this, { pos: a } = this;
		t[a++] = 128, t.fill(0, a), this.padOffset > r - a && (this.process(n, 0), t.fill(0)), Gs(n, r - 8, this.length * 8, i), this.process(n, 0), this.roundClean();
		let o = e === t ? n : tc(e), s = this.outputLen, c = s / 4, l = this.get();
		if (s % 4 || c > l.length) throw Error("invalid outputLen");
		for (let e = 0; e < c; e++) o.setUint32(4 * e, l[e], i);
	}
	digest() {
		let { buffer: e, outputLen: t } = this;
		this.digestInto(e);
		let n = e.slice(0, t);
		return this.destroy(), n;
	}
	_cloneIntoMeta(e) {
		let { buffer: t, length: n, finished: r, destroyed: i, pos: a } = this;
		return e.destroyed = i, e.finished = r, e.length = n, e.pos = a, a && e.buffer.set(t), e;
	}
	clone() {
		return this._cloneInto();
	}
}, cc = /* @__PURE__ */ Uint32Array.from([
	1779033703,
	3144134277,
	1013904242,
	2773480762,
	1359893119,
	2600822924,
	528734635,
	1541459225
]), lc = /* @__PURE__ */ Uint32Array.from([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]), X = /* @__PURE__ */ new Uint32Array(64), uc = class extends sc {
	A = 0;
	B = 0;
	C = 0;
	D = 0;
	E = 0;
	F = 0;
	G = 0;
	H = 0;
	constructor(e, t) {
		super(64, e, 8, !1), this.A = t[0] | 0, this.B = t[1] | 0, this.C = t[2] | 0, this.D = t[3] | 0, this.E = t[4] | 0, this.F = t[5] | 0, this.G = t[6] | 0, this.H = t[7] | 0;
	}
	get() {
		let { A: e, B: t, C: n, D: r, E: i, F: a, G: o, H: s } = this;
		return [
			e,
			t,
			n,
			r,
			i,
			a,
			o,
			s
		];
	}
	set(e, t, n, r, i, a, o, s) {
		this.A = e | 0, this.B = t | 0, this.C = n | 0, this.D = r | 0, this.E = i | 0, this.F = a | 0, this.G = o | 0, this.H = s | 0;
	}
	_cloneInto(e) {
		return (e ||= new this.constructor()).set(...this.get()), this._cloneIntoMeta(e);
	}
	process(e, t) {
		for (let n = 0; n < 16; n++, t += 4) X[n] = e.getUint32(t, !1);
		for (let e = 16; e < 64; e++) {
			let t = X[e - 15], n = X[e - 2], r = Y(t, 7) ^ Y(t, 18) ^ t >>> 3, i = Y(n, 17) ^ Y(n, 19) ^ n >>> 10;
			X[e] = i + X[e - 7] + r + X[e - 16] | 0;
		}
		let { A: n, B: r, C: i, D: a, E: o, F: s, G: c, H: l } = this;
		for (let e = 0; e < 64; e++) {
			let t = Y(o, 6) ^ Y(o, 11) ^ Y(o, 25), u = l + t + ac(o, s, c) + lc[e] + X[e] | 0, d = (Y(n, 2) ^ Y(n, 13) ^ Y(n, 22)) + oc(n, r, i) | 0;
			l = c, c = s, s = o, o = a + u | 0, a = i, i = r, r = n, n = u + d | 0;
		}
		n = n + this.A | 0, r = r + this.B | 0, i = i + this.C | 0, a = a + this.D | 0, o = o + this.E | 0, s = s + this.F | 0, c = c + this.G | 0, l = l + this.H | 0, this.set(n, r, i, a, o, s, c, l);
	}
	roundClean() {
		ec(X);
	}
	destroy() {
		this.destroyed = !0, this.set(0, 0, 0, 0, 0, 0, 0, 0), ec(this.buffer);
	}
}, dc = class extends uc {
	constructor() {
		super(32, cc);
	}
}, fc = /* @__PURE__ */ rc(() => new dc(), /* @__PURE__ */ ic(1)), pc = {
	specVersion: "1.0.0",
	schemaVersion: 1,
	protocolVersion: 1,
	workingName: "留底",
	slug: "upload-ledger",
	browser: {
		family: "Chromium",
		minimumChromeVersion: "120",
		primaryOS: "macOS",
		incognito: "not_allowed",
		topFrameOnly: !0
	},
	capture: {
		maxFileBytes: 52428800,
		maxBatchBytes: 209715200,
		maxBatchFiles: 100,
		rawChunkBytes: 262144,
		maxWireMessageBytes: 524288,
		maxInFlightChunksPerFile: 1,
		maxActiveFilesPerDocument: 1,
		maxActiveFilesGlobal: 2,
		ackTimeoutMs: 1e4,
		retryBackoffMs: [
			250,
			1e3,
			3e3
		],
		sessionIdleExpiryMs: 12e4,
		sessionAbsoluteExpiryMs: 6e5,
		terminalSessionRetentionMs: 864e5,
		sourceLossGraceMs: 15e3,
		dropCaptureDefault: !1,
		requireTrustedEvent: !0
	},
	storage: {
		defaultBudgetBytes: 1073741824,
		minimumBudgetBytes: 104857600,
		maximumBudgetBytes: 5368709120,
		warningFraction: .8,
		estimatedFreeSpaceMarginBytes: 52428800,
		automaticRetentionEnabled: !1,
		cleanupAlarmMinutes: 1,
		cleanupMaxChunksPerTick: 200,
		localEncryption: "none"
	},
	privacy: {
		initialSiteAllowlist: [],
		globalPaused: !1,
		pageLocationMode: "origin_path",
		stripQuery: !0,
		stripFragment: !0,
		savePageTitle: !0,
		savePageBody: !1,
		saveLocalAbsolutePath: !1,
		networkTelemetry: !1,
		cloudSync: !1,
		externalAI: !1,
		clipboardCapture: !1
	},
	limits: {
		fileNameChars: 1024,
		pageTitleChars: 256,
		pageLocationChars: 4096,
		userLabelChars: 120,
		noteChars: 4e3,
		tagChars: 32,
		tagsPerRecord: 10,
		batchBeginRatePerDocumentPerMinute: 30,
		textPreviewBytes: 2097152,
		textDiffBytesPerSide: 1048576,
		imageMaxDecodedPixels: 4e7,
		pdfPreviewMaxPages: 500,
		pdfPreviewTimeoutMs: 15e3,
		listPageSize: 100,
		previewCacheBytes: 67108864
	},
	backup: {
		format: "upload-ledger-backup",
		formatVersion: 1,
		maxManifestBytes: 20971520,
		maxRecords: 1e4,
		maxAuditEvents: 1e5,
		maxObjectCount: 1e4,
		maxArchiveUncompressedBytes: 5368709120,
		maxObjectBytes: 52428800,
		blobFallbackMaxBytes: 209715200,
		jobLeaseMs: 9e5,
		encrypted: !1
	},
	excludedFileNames: [
		".env",
		".env.*",
		"id_rsa",
		"id_dsa",
		"id_ecdsa",
		"id_ed25519",
		"*.pem",
		"*.key",
		"*.p12",
		"*.pfx",
		"*.kdbx"
	],
	locale: {
		default: "zh-CN",
		supported: ["zh-CN", "en-GB"]
	}
}, mc = pc.capture.rawChunkBytes, hc = pc.capture.maxFileBytes, gc = (e) => Array.from(fc(e), (e) => e.toString(16).padStart(2, "0")).join(""), _c = (e) => Array.from(e, (e) => e.toString(16).padStart(2, "0")).join("");
function Z(e) {
	throw Error(e);
}
function vc(e, t = "origin_path") {
	let n;
	try {
		n = new URL(e);
	} catch {
		return Z("E_INVALID_URL");
	}
	return ["http:", "https:"].includes(n.protocol) || Z("E_INVALID_URL"), (n.origin + (t === "origin_only" ? "" : n.pathname)).slice(0, 4096);
}
function yc(e) {
	let t = new URL(vc(e));
	return `${t.protocol}//${t.hostname}/*`;
}
function bc(e) {
	return pc.excludedFileNames.some((t) => RegExp("^" + t.split("").map((e) => e === "*" ? ".*" : e === "?" ? "." : e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("") + "$", "i").test(e));
}
function xc(e) {
	let t = "";
	for (let n = 0; n < e.length; n += 8192) t += String.fromCharCode(...e.subarray(n, n + 8192));
	return btoa(t);
}
function Sc(e, t) {
	(e.length !== 4 * Math.ceil(t / 3) || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(e)) && Z("E_BAD_MESSAGE");
	let n = Uint8Array.from(atob(e), (e) => e.charCodeAt(0));
	return (n.length !== t || xc(n) !== e) && Z("E_BAD_MESSAGE"), n;
}
//#endregion
//#region src/background/capture.ts
var Cc = () => (/* @__PURE__ */ new Date()).toISOString();
async function wc(e, t, n, r) {
	let i = await J(e);
	i.vaultEpoch !== n && Z("E_VAULT_EPOCH"), i.paused && Z("E_PAUSED");
	let a = await e.objectStore("sites").get(t.origin);
	return a?.enabled || Z("E_SITE_DISABLED"), r && (r.policyEpoch.global !== i.globalPolicyEpoch || r.policyEpoch.site !== a.sitePolicyEpoch) && Z("E_PERMISSION_REVOKED"), {
		runtime: i,
		site: a
	};
}
function Tc(e, t) {
	return e.kind === t.kind && e.tabId === t.tabId && e.documentId === t.documentId && e.origin === t.origin && e.frameId === t.frameId;
}
async function Q(e, t, n, r) {
	let i = await e.objectStore("sessions").get(t.sessionId);
	return (!i || i.token !== t.token || !Tc(i.caller, n)) && Z("E_SESSION_MISMATCH"), await wc(e, n, r, i), i.status === "aborted" && Z("E_SESSION_EXPIRED"), i.status !== "committed" && (Date.parse(i.expiresAt) < Date.now() || Date.parse(i.absoluteExpiresAt) < Date.now()) && Z("E_SESSION_EXPIRED"), i;
}
function $(e) {
	return {
		recordId: e.recordId,
		state: e.status,
		nextChunkIndex: e.nextChunkIndex,
		receivedBytes: e.receivedBytes,
		retryAfterMs: null
	};
}
function Ec(e, t) {
	return {
		batchId: e.batchId,
		files: [{
			clientFileId: t,
			recordId: e.recordId,
			sessionId: e.sessionId,
			token: e.token,
			state: "capturing",
			nextChunkIndex: e.nextChunkIndex,
			errorCode: null
		}]
	};
}
async function Dc(e, t, n) {
	return (e.page.origin !== t.origin || new URL(vc(e.page.location)).origin !== t.origin) && Z("E_UNAUTHORISED"), q(async (r) => {
		let { runtime: i, site: a } = await wc(r, t, n), o = e.files[0], s = `${t.tabId}:${t.documentId}:${e.batchEventId}`, c = await r.objectStore("batches").get(s);
		if (c) {
			let e = await r.objectStore("sessions").get(c.sessionId);
			return (!e || c.clientFileId !== o.clientFileId) && Z("E_BAD_MESSAGE"), await Q(r, {
				sessionId: e.sessionId,
				token: e.token
			}, t, n), Ec(e, o.clientFileId);
		}
		let l = await r.objectStore("sessions").getAll();
		l.filter((e) => Tc(e.caller, t) && Date.parse(e.createdAt) > Date.now() - 6e4).length >= 30 && Z("E_RATE_LIMIT");
		let u = l.filter((e) => ["capturing", "finalising"].includes(e.status));
		(u.length >= 2 || u.some((e) => Tc(e.caller, t))) && Z("E_BUSY");
		let d = (await r.objectStore("objects").getAll()).reduce((e, t) => e + t.byteLength, 0) + u.reduce((e, t) => e + t.expectedBytes, 0), f = bc(o.name) ? "E_EXCLUDED_FILE" : o.byteLength > hc ? "E_FILE_TOO_LARGE" : d + o.byteLength > i.budgetBytes ? "E_BUDGET_EXCEEDED" : null, p = crypto.randomUUID(), m = crypto.randomUUID(), h = Cc(), { clientFileId: ee, ...g } = o, _ = {
			recordId: p,
			batchId: m,
			observedAt: h,
			source: "standard_input",
			page: {
				origin: t.origin,
				location: vc(e.page.location, a.locationMode),
				locationMode: a.locationMode,
				title: a.saveTitle ? e.page.title : null
			},
			file: g,
			snapshot: {
				state: f ? "metadata_only" : "capturing",
				objectSha256: null,
				capturedAt: null,
				errorCode: f
			},
			submission: {
				state: "unknown",
				updatedAt: null
			},
			user: {
				label: null,
				note: "",
				tags: [],
				pinned: !1
			},
			revision: 0,
			importedAt: null,
			importJobId: null
		};
		if (await r.objectStore("records").put(_), f) return {
			batchId: m,
			files: [{
				clientFileId: ee,
				recordId: p,
				sessionId: null,
				token: null,
				state: "metadata_only",
				nextChunkIndex: 0,
				errorCode: f
			}]
		};
		let v = btoa(String.fromCharCode(...crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(32)))).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", ""), y = {
			vaultEpoch: i.vaultEpoch,
			sessionId: crypto.randomUUID(),
			recordId: p,
			batchId: m,
			payloadId: crypto.randomUUID(),
			token: v,
			caller: t,
			policyEpoch: {
				global: i.globalPolicyEpoch,
				site: a.sitePolicyEpoch
			},
			status: "capturing",
			expectedBytes: o.byteLength,
			nextChunkIndex: 0,
			receivedBytes: 0,
			reservedRemainingBytes: o.byteLength,
			createdAt: h,
			lastProgressAt: h,
			expiresAt: new Date(Date.now() + 12e4).toISOString(),
			absoluteExpiresAt: new Date(Date.now() + 6e5).toISOString()
		};
		return await r.objectStore("sessions").put(y), await r.objectStore("batches").put({
			key: s,
			sessionId: y.sessionId,
			clientFileId: ee
		}), Ec(y, ee);
	});
}
async function Oc(e, t, n) {
	let r = Sc(e.base64, e.rawLength);
	return gc(r) !== e.chunkSha256 && Z("E_CHUNK_HASH"), q(async (i) => {
		let a = await Q(i, e, t, n);
		if (e.index < a.nextChunkIndex) {
			let t = await i.objectStore("chunks").get([a.payloadId, e.index]);
			return (!t || t.chunkSha256 !== e.chunkSha256 || t.rawLength !== e.rawLength) && Z("E_CHUNK_CONFLICT"), $(a);
		}
		return (a.status !== "capturing" || e.index !== a.nextChunkIndex) && Z("E_CHUNK_ORDER"), e.rawLength !== Math.min(mc, a.expectedBytes - a.receivedBytes) && Z("E_BAD_MESSAGE"), await i.objectStore("chunks").put({
			payloadId: a.payloadId,
			index: e.index,
			bytes: r.buffer,
			rawLength: e.rawLength,
			chunkSha256: e.chunkSha256
		}), a.receivedBytes += e.rawLength, a.reservedRemainingBytes -= e.rawLength, a.nextChunkIndex++, a.lastProgressAt = Cc(), a.expiresAt = new Date(Date.now() + 12e4).toISOString(), await i.objectStore("sessions").put(a), $(a);
	});
}
async function kc(e, t, n) {
	let r = await q(async (r) => {
		let i = await Q(r, e, t, n);
		if (i.status === "committed") return i;
		(i.receivedBytes !== i.expectedBytes || i.nextChunkIndex !== Math.ceil(i.expectedBytes / mc)) && Z("E_CHUNK_ORDER"), i.status = "finalising", await r.objectStore("sessions").put(i);
		let a = await r.objectStore("records").get(i.recordId);
		return a.snapshot.state = "finalising", await r.objectStore("records").put(a), i;
	});
	if (r.status === "committed") return $(r);
	let i = await K(), a;
	try {
		let e = fc.create(), t = 0;
		for (let n = 0; n < r.nextChunkIndex; n++) {
			let a = await i.get("chunks", [r.payloadId, n]);
			a || Z("E_INTEGRITY");
			let o = new Uint8Array(a.bytes);
			gc(o) !== a.chunkSha256 && Z("E_INTEGRITY"), e.update(o), t += o.length;
		}
		t !== r.expectedBytes && Z("E_INTEGRITY"), a = _c(e.digest());
	} finally {
		i.close();
	}
	return q(async (i) => {
		let o = await Q(i, e, t, n);
		if (o.status === "committed") return $(o);
		let s = await i.objectStore("objects").get(a);
		s ? ((s.byteLength !== r.expectedBytes || s.integrityState !== "verified") && Z("E_HASH_CONFLICT"), s.refCount++, await i.objectStore("objects").put(s), await i.objectStore("chunks").delete(IDBKeyRange.bound([r.payloadId, 0], [r.payloadId, 2 ** 53 - 1]))) : await i.objectStore("objects").put({
			sha256: a,
			byteLength: r.expectedBytes,
			payloadId: r.payloadId,
			chunkCount: r.nextChunkIndex,
			refCount: 1,
			createdAt: Cc(),
			integrityState: "verified"
		});
		let c = await i.objectStore("records").get(r.recordId);
		return c.snapshot = {
			state: "ready",
			objectSha256: a,
			capturedAt: Cc(),
			errorCode: null
		}, c.revision++, await i.objectStore("records").put(c), o.status = "committed", o.reservedRemainingBytes = 0, await i.objectStore("sessions").put(o), await i.objectStore("audit").put({
			eventId: crypto.randomUUID(),
			recordId: c.recordId,
			createdAt: Cc(),
			actor: "system",
			type: "snapshot_saved",
			from: "finalising",
			to: "ready",
			note: null
		}), $(o);
	});
}
async function Ac(e, t, n) {
	if (["committed", "aborted"].includes(t.status)) return;
	let r = await e.objectStore("records").get(t.recordId);
	r && (r.snapshot = {
		state: "interrupted",
		objectSha256: null,
		capturedAt: null,
		errorCode: n
	}, r.revision++, await e.objectStore("records").put(r)), t.status = "aborted", t.reservedRemainingBytes = 0, await e.objectStore("sessions").put(t), await e.objectStore("chunks").delete(IDBKeyRange.bound([t.payloadId, 0], [t.payloadId, 2 ** 53 - 1]));
}
async function jc(e, t, n) {
	return q(async (r) => $(await Q(r, e, t, n)));
}
async function Mc(e, t, n, r) {
	return q(async (i) => {
		let a = await Q(i, e, t, n);
		return await Ac(i, a, r), $(a);
	});
}
async function Nc(e) {
	let t = await K(), n = await t.getAll("sessions");
	t.close();
	for (let t of n) if (!["committed", "aborted"].includes(t.status) && (!e || Tc(t.caller, e))) {
		if (t.receivedBytes === t.expectedBytes) {
			await kc(t, t.caller, t.vaultEpoch).catch(() => {});
			continue;
		}
		(e || Date.parse(t.expiresAt) < Date.now() || Date.parse(t.absoluteExpiresAt) < Date.now()) && await q(async (n) => {
			let r = await n.objectStore("sessions").get(t.sessionId);
			r && r.receivedBytes < r.expectedBytes && await Ac(n, r, e ? "E_SOURCE_GONE" : "E_SESSION_EXPIRED");
		});
	}
}
//#endregion
//#region src/shared/error-codes.json
var Pc = [
	{
		code: "E_UNAUTHORISED",
		messageKey: "error.E_UNAUTHORISED",
		"zh-CN": "无权执行此操作",
		"en-GB": "This action is not authorised",
		retryable: !1
	},
	{
		code: "E_SITE_DISABLED",
		messageKey: "error.E_SITE_DISABLED",
		"zh-CN": "此站点尚未启用留底",
		"en-GB": "Saving is disabled for this site",
		retryable: !1
	},
	{
		code: "E_PAUSED",
		messageKey: "error.E_PAUSED",
		"zh-CN": "留底已暂停",
		"en-GB": "Saving is paused",
		retryable: !1
	},
	{
		code: "E_PERMISSION_REVOKED",
		messageKey: "error.E_PERMISSION_REVOKED",
		"zh-CN": "站点权限已撤销",
		"en-GB": "Site permission was revoked",
		retryable: !1
	},
	{
		code: "E_UNSUPPORTED_CONTEXT",
		messageKey: "error.E_UNSUPPORTED_CONTEXT",
		"zh-CN": "此页面或控件暂不支持自动留底",
		"en-GB": "Automatic capture is unavailable here",
		retryable: !1
	},
	{
		code: "E_BAD_MESSAGE",
		messageKey: "error.E_BAD_MESSAGE",
		"zh-CN": "消息格式无效",
		"en-GB": "Invalid message format",
		retryable: !1
	},
	{
		code: "E_MESSAGE_TOO_LARGE",
		messageKey: "error.E_MESSAGE_TOO_LARGE",
		"zh-CN": "消息超过大小限制",
		"en-GB": "Message size limit exceeded",
		retryable: !1
	},
	{
		code: "E_FILE_TOO_LARGE",
		messageKey: "error.E_FILE_TOO_LARGE",
		"zh-CN": "文件超过副本大小上限",
		"en-GB": "File exceeds the copy size limit",
		retryable: !1
	},
	{
		code: "E_BATCH_LIMIT",
		messageKey: "error.E_BATCH_LIMIT",
		"zh-CN": "本批文件数量或总大小超过上限",
		"en-GB": "Batch size or file count limit exceeded",
		retryable: !1
	},
	{
		code: "E_EXCLUDED_FILE",
		messageKey: "error.E_EXCLUDED_FILE",
		"zh-CN": "已按文件排除规则跳过",
		"en-GB": "Skipped by the file exclusion rule",
		retryable: !1
	},
	{
		code: "E_DIRECTORY_UNSUPPORTED",
		messageKey: "error.E_DIRECTORY_UNSUPPORTED",
		"zh-CN": "目录上传请改为选择单独文件",
		"en-GB": "Select individual files for this upload",
		retryable: !1
	},
	{
		code: "E_BUDGET_EXCEEDED",
		messageKey: "error.E_BUDGET_EXCEEDED",
		"zh-CN": "本地资料库容量不足",
		"en-GB": "Local library budget exceeded",
		retryable: !1
	},
	{
		code: "E_STORAGE_WRITE",
		messageKey: "error.E_STORAGE_WRITE",
		"zh-CN": "本地写入失败",
		"en-GB": "Local storage write failed",
		retryable: !1
	},
	{
		code: "E_QUOTA",
		messageKey: "error.E_QUOTA",
		"zh-CN": "浏览器或磁盘可用空间不足",
		"en-GB": "Browser or disk space is insufficient",
		retryable: !1
	},
	{
		code: "E_READ_FAILED",
		messageKey: "error.E_READ_FAILED",
		"zh-CN": "无法读取本次选择的文件",
		"en-GB": "The selected file could not be read",
		retryable: !1
	},
	{
		code: "E_SOURCE_CHANGED",
		messageKey: "error.E_SOURCE_CHANGED",
		"zh-CN": "复制时源文件发生变化",
		"en-GB": "The source file changed during capture",
		retryable: !1
	},
	{
		code: "E_SOURCE_GONE",
		messageKey: "error.E_SOURCE_GONE",
		"zh-CN": "页面已离开，副本保存中断",
		"en-GB": "The source page closed before capture finished",
		retryable: !1
	},
	{
		code: "E_SESSION_EXPIRED",
		messageKey: "error.E_SESSION_EXPIRED",
		"zh-CN": "保存会话已过期，请重新选择文件",
		"en-GB": "Capture expired; select the file again",
		retryable: !1
	},
	{
		code: "E_SESSION_MISMATCH",
		messageKey: "error.E_SESSION_MISMATCH",
		"zh-CN": "保存会话来源不匹配",
		"en-GB": "Capture session source mismatch",
		retryable: !1
	},
	{
		code: "E_CHUNK_ORDER",
		messageKey: "error.E_CHUNK_ORDER",
		"zh-CN": "正在恢复文件传输位置",
		"en-GB": "Restoring the transfer position",
		retryable: !0
	},
	{
		code: "E_CHUNK_CONFLICT",
		messageKey: "error.E_CHUNK_CONFLICT",
		"zh-CN": "重复文件块内容不一致",
		"en-GB": "Conflicting duplicate chunk",
		retryable: !1
	},
	{
		code: "E_CHUNK_HASH",
		messageKey: "error.E_CHUNK_HASH",
		"zh-CN": "文件块校验失败",
		"en-GB": "Chunk integrity check failed",
		retryable: !0
	},
	{
		code: "E_HASH_CONFLICT",
		messageKey: "error.E_HASH_CONFLICT",
		"zh-CN": "文件摘要与对象信息冲突",
		"en-GB": "File hash and object metadata conflict",
		retryable: !1
	},
	{
		code: "E_ACK_TIMEOUT",
		messageKey: "error.E_ACK_TIMEOUT",
		"zh-CN": "保存确认超时",
		"en-GB": "Save acknowledgement timed out",
		retryable: !0
	},
	{
		code: "E_RATE_LIMIT",
		messageKey: "error.E_RATE_LIMIT",
		"zh-CN": "操作过于频繁，请稍后重试",
		"en-GB": "Too many operations; retry shortly",
		retryable: !0
	},
	{
		code: "E_BUSY",
		messageKey: "error.E_BUSY",
		"zh-CN": "当前保存任务繁忙",
		"en-GB": "Capture queue is busy",
		retryable: !0
	},
	{
		code: "E_OBJECT_MISSING",
		messageKey: "error.E_OBJECT_MISSING",
		"zh-CN": "归档文件内容缺失",
		"en-GB": "Archived file content is missing",
		retryable: !1
	},
	{
		code: "E_INTEGRITY",
		messageKey: "error.E_INTEGRITY",
		"zh-CN": "副本完整性校验失败",
		"en-GB": "Copy integrity verification failed",
		retryable: !1
	},
	{
		code: "E_CONFLICT",
		messageKey: "error.E_CONFLICT",
		"zh-CN": "记录已变化，请刷新后重试",
		"en-GB": "The record changed; refresh and retry",
		retryable: !1
	},
	{
		code: "E_OBJECT_IN_USE",
		messageKey: "error.E_OBJECT_IN_USE",
		"zh-CN": "文件正在预览或导出，请结束任务后重试",
		"en-GB": "The file is in use by a preview or export",
		retryable: !0
	},
	{
		code: "E_CLEARING",
		messageKey: "error.E_CLEARING",
		"zh-CN": "资料库正在清除",
		"en-GB": "The library is being cleared",
		retryable: !0
	},
	{
		code: "E_INVALID_URL",
		messageKey: "error.E_INVALID_URL",
		"zh-CN": "来源地址无效或不受支持",
		"en-GB": "Invalid or unsupported source address",
		retryable: !1
	},
	{
		code: "E_PREVIEW_UNSUPPORTED",
		messageKey: "error.E_PREVIEW_UNSUPPORTED",
		"zh-CN": "此文件可下载原件查看",
		"en-GB": "Download the original to view this file",
		retryable: !1
	},
	{
		code: "E_PREVIEW_LIMIT",
		messageKey: "error.E_PREVIEW_LIMIT",
		"zh-CN": "预览超过大小、页数或像素限制",
		"en-GB": "Preview size, page or pixel limit exceeded",
		retryable: !1
	},
	{
		code: "E_PREVIEW_FAILED",
		messageKey: "error.E_PREVIEW_FAILED",
		"zh-CN": "预览暂不可用，原件仍可下载",
		"en-GB": "Preview unavailable; the original remains available",
		retryable: !1
	},
	{
		code: "E_ARCHIVE_FORMAT",
		messageKey: "error.E_ARCHIVE_FORMAT",
		"zh-CN": "备份格式或版本不受支持",
		"en-GB": "Unsupported backup format or version",
		retryable: !1
	},
	{
		code: "E_ARCHIVE_PATH",
		messageKey: "error.E_ARCHIVE_PATH",
		"zh-CN": "备份包含无效或重复路径",
		"en-GB": "The backup contains invalid or duplicate paths",
		retryable: !1
	},
	{
		code: "E_ARCHIVE_LIMIT",
		messageKey: "error.E_ARCHIVE_LIMIT",
		"zh-CN": "备份超过安全处理上限",
		"en-GB": "Backup safety limit exceeded",
		retryable: !1
	},
	{
		code: "E_ARCHIVE_HASH",
		messageKey: "error.E_ARCHIVE_HASH",
		"zh-CN": "备份文件完整性校验失败",
		"en-GB": "Backup object integrity check failed",
		retryable: !1
	},
	{
		code: "E_ARCHIVE_REFERENCE",
		messageKey: "error.E_ARCHIVE_REFERENCE",
		"zh-CN": "备份中的文件引用不完整",
		"en-GB": "The backup has invalid object references",
		retryable: !1
	},
	{
		code: "E_IMPORT_CONFLICT",
		messageKey: "error.E_IMPORT_CONFLICT",
		"zh-CN": "导入记录与当前资料库存在冲突",
		"en-GB": "Imported records conflict with the current library",
		retryable: !1
	},
	{
		code: "E_IMPORT_CANCELLED",
		messageKey: "error.E_IMPORT_CANCELLED",
		"zh-CN": "导入已取消，原资料保留",
		"en-GB": "Import cancelled; existing data was preserved",
		retryable: !1
	},
	{
		code: "E_SCHEMA_NEWER",
		messageKey: "error.E_SCHEMA_NEWER",
		"zh-CN": "资料库来自更高版本，请先升级扩展",
		"en-GB": "Upgrade the extension to read this database version",
		retryable: !1
	},
	{
		code: "E_MIGRATION_FAILED",
		messageKey: "error.E_MIGRATION_FAILED",
		"zh-CN": "资料库升级失败，旧数据已保留",
		"en-GB": "Database upgrade failed; existing data was preserved",
		retryable: !1
	},
	{
		code: "E_USER_CANCELLED",
		messageKey: "error.E_USER_CANCELLED",
		"zh-CN": "操作已取消",
		"en-GB": "Operation cancelled",
		retryable: !1
	},
	{
		code: "E_VAULT_EPOCH",
		messageKey: "error.E_VAULT_EPOCH",
		"zh-CN": "资料库已重置，请刷新后重新操作",
		"en-GB": "The library was reset. Refresh before starting a new action.",
		retryable: !1
	}
];
//#endregion
//#region src/background/index.ts
function Fc(e) {
	(e.id !== chrome.runtime.id || e.tab?.incognito || !e.url) && Z("E_UNAUTHORISED");
	let t = new URL(e.url);
	return t.protocol === "chrome-extension:" && t.hostname === chrome.runtime.id && !t.username && !t.password && ["/app.html", "/popup.html"].includes(t.pathname) ? {
		kind: "ui",
		tabId: e.tab?.id ?? null,
		documentId: e.documentId ?? "",
		frameId: e.frameId ?? 0,
		origin: `chrome-extension://${chrome.runtime.id}`
	} : ((!["http:", "https:"].includes(t.protocol) || e.frameId !== 0 || !e.documentId || e.tab?.id === void 0 || e.origin !== t.origin) && Z("E_UNAUTHORISED"), {
		kind: "capture",
		tabId: e.tab.id,
		documentId: e.documentId,
		frameId: 0,
		origin: t.origin
	});
}
var Ic = (e) => "site-" + Array.from(new TextEncoder().encode(e), (e) => e.toString(16).padStart(2, "0")).join("");
async function Lc() {
	let e = await K(), t = await e.getAll("sites"), n = await e.get("meta", "runtime");
	e.close();
	let r = [];
	for (let e of t) e.enabled && !n?.paused && await chrome.permissions.contains({ origins: [e.permissionPattern] }) && r.push(e);
	let i = await chrome.scripting.getRegisteredContentScripts(), a = i.filter((e) => !r.some((t) => Ic(t.exactOrigin) === e.id)).map((e) => e.id);
	a.length && await chrome.scripting.unregisterContentScripts({ ids: a });
	for (let e of r) i.some((t) => t.id === Ic(e.exactOrigin)) || await chrome.scripting.registerContentScripts([{
		id: Ic(e.exactOrigin),
		matches: [e.permissionPattern],
		js: ["content.js"],
		runAt: "document_start",
		world: "ISOLATED",
		allFrames: !1,
		persistAcrossSessions: !0
	}]);
	for (let e of await chrome.tabs.query({})) if (e.id !== void 0 && e.url) {
		let t = "";
		try {
			t = new URL(e.url).origin;
		} catch {}
		if (r.some((e) => e.exactOrigin === t)) try {
			await chrome.scripting.executeScript({
				target: {
					tabId: e.id,
					allFrames: !1
				},
				files: ["content.js"]
			});
		} catch {}
		else await chrome.tabs.sendMessage(e.id, { type: "CAPTURE_STOP" }).catch(() => {});
	}
}
async function Rc(e, t) {
	let n = new URL(vc(e.origin, "origin_only")).origin;
	n !== e.origin && Z("E_INVALID_URL");
	let r = yc(n);
	e.enabled && !await chrome.permissions.contains({ origins: [r] }) && Z("E_PERMISSION_REVOKED"), await q(async (i) => {
		(await J(i)).vaultEpoch !== t && Z("E_VAULT_EPOCH");
		let a = await i.objectStore("sites").get(n);
		await i.objectStore("sites").put({
			exactOrigin: n,
			enabled: e.enabled,
			dropEnabled: !1,
			locationMode: e.locationMode,
			saveTitle: e.saveTitle,
			permissionPattern: r,
			sitePolicyEpoch: (a?.sitePolicyEpoch ?? 0) + 1
		});
		for (let e of await i.objectStore("sessions").getAll()) e.caller.origin === n && await Ac(i, e, "E_PERMISSION_REVOKED");
	}), await Lc();
	let i = !0;
	if (!e.enabled) {
		let e = await K(), t = (await e.getAll("sites")).some((e) => e.enabled && e.permissionPattern === r);
		if (e.close(), !t) try {
			i = await chrome.permissions.remove({ origins: [r] });
		} catch {
			i = !1;
		}
	}
	return {
		enabled: e.enabled,
		permissionRemoved: i
	};
}
async function zc(e, t) {
	let n;
	try {
		n = ps(e);
	} catch (e) {
		Z(e instanceof Error && e.message === "E_MESSAGE_TOO_LARGE" ? e.message : "E_BAD_MESSAGE");
	}
	let r = Fc(t), i = n.payload;
	if (n.type.startsWith("UI_") !== (r.kind === "ui") && Z("E_UNAUTHORISED"), r.kind === "capture") {
		let e = await chrome.permissions.contains({ origins: [yc(r.origin)] });
		if (n.type === "CAPTURE_HELLO") return q(async (t) => {
			let n = await J(t), i = await t.objectStore("sites").get(r.origin);
			return {
				vaultEpoch: n.vaultEpoch,
				allowed: e && !!i?.enabled && !n.paused,
				paused: n.paused,
				policyEpoch: {
					global: n.globalPolicyEpoch,
					site: i?.sitePolicyEpoch ?? 0
				},
				dropEnabled: !1,
				maxFileBytes: hc,
				rawChunkBytes: mc
			};
		});
		switch (e || Z("E_PERMISSION_REVOKED"), n.type) {
			case "CAPTURE_BEGIN": return Dc(i, r, n.vaultEpoch);
			case "CAPTURE_CHUNK": return Oc(i, r, n.vaultEpoch);
			case "CAPTURE_FINISH": return kc(i, r, n.vaultEpoch);
			case "CAPTURE_RESUME": return jc(i, r, n.vaultEpoch);
			case "CAPTURE_ABORT": return Mc(i, r, n.vaultEpoch, {
				read_failed: "E_READ_FAILED",
				source_changed: "E_SOURCE_CHANGED",
				source_gone: "E_SOURCE_GONE",
				user_cancelled: "E_USER_CANCELLED"
			}[i.reason]);
			case "CAPTURE_SOURCE_GONE": return await Nc(r), {};
		}
	}
	switch (n.type) {
		case "UI_GET_RUNTIME_STATE": return q(J);
		case "UI_GET_SITE_STATUS": {
			let e = await K(), t = await e.get("sites", i.origin);
			return e.close(), {
				site: t ?? null,
				granted: await chrome.permissions.contains({ origins: [yc(i.origin)] })
			};
		}
		case "UI_SET_SITE_POLICY": return Rc(i, n.vaultEpoch);
		case "UI_SET_GLOBAL_PAUSE": return await q(async (e) => {
			let t = await J(e);
			t.vaultEpoch !== n.vaultEpoch && Z("E_VAULT_EPOCH"), t.paused = i.paused, t.globalPolicyEpoch++, await e.objectStore("meta").put(t, "runtime");
			for (let t of await e.objectStore("sessions").getAll()) await Ac(e, t, "E_PAUSED");
		}), await Lc(), {};
		case "UI_SET_SUBMISSION": return q(async (e) => {
			(await J(e)).vaultEpoch !== n.vaultEpoch && Z("E_VAULT_EPOCH");
			for (let t of i.records) {
				let n = await e.objectStore("records").get(t.recordId);
				(!n || n.revision !== t.expectedRevision) && Z("E_CONFLICT");
				let r = n.submission.state;
				n.submission = {
					state: i.state,
					updatedAt: (/* @__PURE__ */ new Date()).toISOString()
				}, n.revision++, await e.objectStore("records").put(n), await e.objectStore("audit").put({
					eventId: crypto.randomUUID(),
					recordId: n.recordId,
					createdAt: n.submission.updatedAt,
					actor: "user",
					type: "submission_changed",
					from: r,
					to: i.state,
					note: i.note
				});
			}
			return {};
		});
	}
	Z("E_BAD_MESSAGE");
}
chrome.runtime.onMessage.addListener((e, t, n) => (zc(e, t).then((t) => n({
	v: 1,
	requestId: e?.requestId ?? null,
	ok: !0,
	data: t
})).catch((t) => {
	let r = Pc.find((e) => e.code === t?.message) ?? Pc.find((e) => e.code === (t?.name === "QuotaExceededError" ? "E_QUOTA" : "E_STORAGE_WRITE"));
	n({
		v: 1,
		requestId: e?.requestId ?? null,
		ok: !1,
		error: {
			code: r.code,
			retryable: r.retryable,
			messageKey: r.messageKey
		}
	});
}), !0)), chrome.permissions.onRemoved.addListener(() => {
	(async () => {
		let e = await K(), t = await e.getAll("sites");
		e.close();
		for (let e of t) if (e.enabled && !await chrome.permissions.contains({ origins: [e.permissionPattern] })) {
			let t = await q(J);
			await Rc({
				origin: e.exactOrigin,
				enabled: !1,
				dropEnabled: !1,
				locationMode: e.locationMode,
				saveTitle: e.saveTitle
			}, t.vaultEpoch);
		}
	})().catch(() => {});
}), chrome.alarms.onAlarm.addListener(() => {
	Nc().catch(() => {});
}), chrome.runtime.onInstalled.addListener(() => {
	Lc().catch(() => {});
}), chrome.runtime.onStartup.addListener(() => {
	Lc().catch(() => {});
}), chrome.alarms.create("recover", { periodInMinutes: 1 }), Nc().catch(() => {});
//#endregion
